// Colonist Tracker - Step 4 (native-style UI)
// Reads the game log (keyed by scroller row index) and feeds TrackerCore.
// UI: a box left of each opponent's row in colonist's own player panel (open by
// default; the blue button on the panel's left edge opens/closes it) showing
// what they are holding, drawn like colonist's own inventory.
//   - resource cards: fanned stacks, top-right running count per card
//   - bottom-left "+n" / "-n" badge = cards of that type that may be extra /
//     missing because of a robber steal we could not identify
//   - unplayed dev cards: face-down stack (count comes from the native panel);
//     hover a card for its chance of being each dev card type
//   - hover colonist's "buy development card" button for the odds of the next
//     card from the deck
//   - the native card-count badge of a player turns red while they have any
//     +/- uncertainty
// Selectors come from content_old.js and the helper paths you gave me:
//   gameFeedsContainer, usernameLarge (me), data-player-information-container,
//   opponentPlayerRow, playerInformation, username, data-resource-card,
//   data-development-card, countBadge, count-, achievementCount,
//   #player-card-inventory [data-card-enum], #action-button-buy-dev-card.

const CT = "[CT]";
const SKIP_ALT = new Set(["Player avatar", "bot"]); // avatar next to the name
const ORDER = ["lumber", "brick", "wool", "grain", "ore"]; // = data-card-enum 1..5
const FACE_RE = {
  lumber: /card_lumber\./,
  brick: /card_brick\./,
  wool: /card_wool\./,
  grain: /card_grain\./,
  ore: /card_ore\./,
  devback: /card_devcardback\./,
  resback: /card_rescardback\./,
};
const PLACEHOLDER = { lumber: "#3f7d3a", brick: "#b5532f", wool: "#8fcf6a", grain: "#e0b83a", ore: "#7d8791", devback: "#35557f", resback: "#35557f" };
const PH_LETTER = { devback: "D", resback: "?" };

let session = null; // { feed, panelEl, observer, tracker, seenIdx, maxIdx, ... }
const boxes = new Map(); // player name -> { host, box, html }
const faceUrl = {}; // key -> image url, harvested from the page
let cardW = null; // native card width in px (measured from colonist's inventory)
let warnedAssets = false;

// ------------------------------------------------------------- tester log ---
// Every [CT] line also goes to chrome.storage.local, so a game played on a
// tester's machine can be reviewed later: the extension's toolbar popup
// (popup.html) downloads the log as a .txt in the recorder's format, which
// review-log.mjs reads as is. One set of keys per page load
// ("ctlog:<start ms>:<chunk>"), chunks of up to LOG_CHUNK characters written
// every 2 s; the oldest page loads go once the total passes LOG_CAP (storage
// holds 10 MB without extra permissions).
const LOG_CAP = 8 * 1024 * 1024;
const LOG_CHUNK = 200 * 1024;
const logStore = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
const logState = { start: String(Date.now()).padStart(13, "0"), chunk: 0, text: "", dirty: false };

function ctLog(text) {
  console.log(text);
  if (!logStore) return;
  const line = `${new Date().toLocaleTimeString("en-US")} [extension] log: ${text}`;
  if (logState.text && logState.text.length + line.length > LOG_CHUNK) {
    flushLog();
    logState.chunk++;
    logState.text = "";
  }
  logState.text += (logState.text ? "\n" : "") + line;
  logState.dirty = true;
}

function flushLog() {
  if (!logStore || !logState.dirty) return;
  logState.dirty = false;
  try {
    const key = `ctlog:${logState.start}:${String(logState.chunk).padStart(4, "0")}`;
    logStore.set({ [key]: logState.text }).catch(() => {});
  } catch (e) {
    /* the extension was reloaded or removed: this copy of the script is orphaned */
  }
}

// Drop the oldest page loads while the log is over LOG_CAP (never this one).
async function pruneLog() {
  if (!logStore) return;
  try {
    const keys = (logStore.getKeys ? await logStore.getKeys() : Object.keys(await logStore.get(null)))
      .filter((k) => k.startsWith("ctlog:"))
      .sort();
    let total = await logStore.getBytesInUse(keys);
    const loads = new Map();
    keys.forEach((k) => {
      const s = k.split(":")[1];
      (loads.get(s) || loads.set(s, []).get(s)).push(k);
    });
    for (const [s, ks] of loads) {
      if (total <= LOG_CAP || s === logState.start) break;
      total -= await logStore.getBytesInUse(ks);
      await logStore.remove(ks);
    }
  } catch (e) {
    /* storage unavailable: the console still has everything */
  }
}

if (logStore) {
  setInterval(flushLog, 2000);
  pruneLog();
  window.addEventListener("pagehide", flushLog);
  // Our own uncaught errors (the page's are not ours: skip them).
  window.addEventListener("error", (e) => {
    if (String(e.filename || "").startsWith("chrome-extension://")) ctLog(`${CT} ERROR | uncaught: ${e.message} (${String(e.filename).split("/").pop()}:${e.lineno})`);
  });
  window.addEventListener("unhandledrejection", (e) => {
    const r = e.reason;
    if (r && String(r.stack || "").includes("chrome-extension://")) ctLog(`${CT} ERROR | unhandled: ${r.message || r}`);
  });
}

ctLog(`${CT} loaded v20`);
try {
  const v = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : "?";
  ctLog(
    `${CT} ENV | extension ${v} | ${navigator.userAgent} | screen ${screen.width}x${screen.height}, window ${innerWidth}x${innerHeight}, ` +
      `zoom ${devicePixelRatio} | ${location.href}`
  );
} catch (e) {
  /* not in a browser (tests) */
}
// The page's list of loaded files (used to find colonist's images) stops at 250
// entries by default; game assets that load later would be missing from it.
try {
  performance.setResourceTimingBufferSize(3000);
} catch (e) {
  /* not supported: harvest from <img> elements only */
}

// ------------------------------------------------------------ page reading ---
// The feed (gameFeedsContainer) holds two lists: the game log and, under it, the
// player chat ([class*="chatContainer"]; read-only probe probes/feeds.js,
// 2026-10-16, the user to confirm). Both are virtual lists with the same row
// markup, each numbering its rows from 0, so a chat row has a log row's
// data-index. Reading the whole feed let chat rows take log rows' places: after
// a reload the chat's rows were read first and the log rows with the same
// numbers were skipped (the user's hunch from a beta tester who played with
// the chat open; seen live: "qwertfup : hello" read as log row 1).
const inChat = (el) => !!(el.closest && el.closest('[class*="chatContainer"]'));
function logRows(feed) {
  return [...feed.querySelectorAll('div[class*="scrollItemContainer"][data-index]')].filter((el) => !inChat(el));
}
function logScroller(feed) {
  return [...feed.querySelectorAll('div[class*="virtualContainer"]')].find((el) => !inChat(el)) || null;
}

// Turns a message element into one line of text, with icons written as <alt>.
function flatten(node) {
  let out = "";
  node.childNodes.forEach((n) => {
    if (n.nodeType === Node.TEXT_NODE) out += n.textContent;
    else if (n.nodeName === "IMG") {
      const alt = n.getAttribute("alt") ?? "img";
      if (alt === "robber" && n.src && !pieceUrl.logRobber) pieceUrl.logRobber = n.src; // icon for the rob boxes
      if (!SKIP_ALT.has(alt)) out += ` <${alt}> `;
    } else out += " " + flatten(n) + " ";
  });
  return out.replace(/\s+/g, " ").trim();
}

function panelRows() {
  return [
    ...document.querySelectorAll('[data-player-information-container="true"] [data-player-color]'),
  ];
}

const rowName = (row) => row.querySelector('div[class*="username"]')?.textContent.trim();

function readPanel() {
  return panelRows().map((row) => {
    const count = (attr) =>
      row.querySelector(`[${attr}="true"] [class*="count-"]`)?.textContent.trim();
    const knights = row
      .querySelector('div[class*="achievementCount"]')
      ?.textContent.trim();
    return {
      name: rowName(row),
      color: row.getAttribute("data-player-color"),
      hand: count("data-resource-card"),
      dev: count("data-development-card"),
      knights,
    };
  });
}

function findMe() {
  return document.querySelector('div[class*="usernameLarge"]')?.textContent.trim() || null;
}

// Whose turn it is: colonist gives that player's playerInformation element an
// "active-…" class (seen on the user's own row in content_old.js and live on
// 2026-10-15; the dice images use "inactive-…", so match the class start).
function readCurrentPlayer() {
  for (const row of panelRows()) {
    const info = row.querySelector('[class*="playerInformation"]');
    if (info && [...info.classList].some((c) => c.startsWith("active-"))) return rowName(row);
  }
  return null;
}

function syncTurn(s) {
  if (!s || s.catching) return;
  const name = readCurrentPlayer();
  if (!name || name === s.turnName) return;
  s.turnName = name;
  s.tracker.setCurrentPlayer(name);
  const before = s.tracker.playerBefore(name);
  ctLog(`${CT} TURN | ${name}${before ? ` (after ${before})` : ""}`);
}

// ----------------------------------------------------- my own dev cards ---
// Our own unplayed dev cards sit in the same inventory strip, after a divider
// (class "partition"). Card enums and image names are from colonist's own JS
// bundle (checked 2026-10-14): 0 ResourceBack, 1-5 lumber..ore, 6-8 commodities,
// 9 AnyResource (drawn with the resource card back; it shows up while you put a
// trade offer together), 10 DevelopmentBack, 11 Knight, 12 VictoryPoint,
// 13 Monopoly, 14 RoadBuilding, 15 YearOfPlenty. Seen in a game so far: 9, 12.
// Cards that are not dev cards are skipped; a dev card we cannot name makes the
// answer "unknown" rather than a guess.
const DEV_BY_IMG = [
  [/card_vp\./, "Victory Point"],
  [/card_knight\./, "Knight"],
  [/card_monopoly\./, "Monopoly"],
  [/card_yearofplenty\./, "Year of Plenty"],
  [/card_roadbuilding\./, "Road Building"],
];
const DEV_BY_ENUM = { 11: "Knight", 12: "Victory Point", 13: "Monopoly", 14: "Road Building", 15: "Year of Plenty" };
const NOT_DEV_ENUM = new Set(["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]);

const seenDevImgs = new Set(); // log each card image seen in the dev section once

// Our exact resource hand, straight from colonist's inventory strip (cards
// before the divider). Used only to check the tracker against ground truth.
function readMyHand() {
  const inv = document.querySelector("#player-card-inventory");
  if (!inv) return null;
  const part = inv.querySelector('[class*="partition"]');
  const out = { lumber: 0, brick: 0, wool: 0, grain: 0, ore: 0 };
  for (const card of inv.querySelectorAll("[data-card-enum]")) {
    if (part && part.compareDocumentPosition(card) & Node.DOCUMENT_POSITION_FOLLOWING) continue; // dev section
    const m = ((card.querySelector("img") || {}).src || "").match(/card_(lumber|brick|wool|grain|ore)\./);
    if (!m) return null;
    out[m[1]]++;
  }
  return out;
}

function readMyDev() {
  const inv = document.querySelector("#player-card-inventory");
  if (!inv) return null;
  const out = {};
  const part = inv.querySelector('[class*="partition"]');
  if (!part) return out; // no dev section: we hold none
  for (let el = part.nextElementSibling; el; el = el.nextElementSibling) {
    for (const card of el.querySelectorAll("[data-card-enum]")) {
      const num = card.getAttribute("data-card-enum");
      const src = (card.querySelector("img") || {}).src || "";
      const hit = DEV_BY_IMG.find(([re]) => re.test(src));
      const type = hit ? hit[1] : DEV_BY_ENUM[num];
      const skip = !type && NOT_DEV_ENUM.has(num);
      const imgName = src.replace(/.*assets\//, "").replace(/\.[0-9a-f]+\.svg/, "");
      if (!seenDevImgs.has(imgName)) {
        seenDevImgs.add(imgName);
        ctLog(`${CT} MYDEV | image seen: ${imgName} (enum ${num}) -> ${type || (skip ? "not a dev card, skipped" : "UNRECOGNISED")}`);
      }
      if (skip) continue;
      if (!type) return null;
      out[type] = (out[type] || 0) + 1;
    }
  }
  return out;
}

// Keep the tracker informed of our exact dev cards. If the page and the log
// briefly disagree about how many we hold (they update at different moments)
// we keep the last answer for 3 seconds before falling back to "unknown".
function syncMyDev() {
  const s = session;
  if (!s || s.catching) return;
  const me = s.tracker.state.me;
  if (!me) return;
  let obj = readMyDev();
  const tracked = (s.tracker.state.players[me] || { devCards: [] }).devCards.length;
  if (obj && Object.values(obj).reduce((a, b) => a + b, 0) !== tracked) {
    if (!s.myDevBad) s.myDevBad = Date.now();
    if (Date.now() - s.myDevBad < 3000) return;
    obj = null;
  } else {
    s.myDevBad = 0;
  }
  const key = JSON.stringify(obj);
  if (key !== s.myDevKey) {
    s.myDevKey = key;
    s.tracker.setMyDev(obj);
    ctLog(`${CT} MYDEV | ${key}`);
    render();
  }
}

// ------------------------------------------------------------------ assets ---
// Card images have hashed file names, so read their URLs from what the page
// already loaded (log icons, panel card backs, your own inventory).
function harvestAssets() {
  const urls = [...document.images].map((i) => i.src);
  if (Object.keys(FACE_RE).some((k) => !faceUrl[k])) {
    performance.getEntriesByType("resource").forEach((r) => urls.push(r.name));
  }
  for (const [key, re] of Object.entries(FACE_RE)) {
    if (faceUrl[key]) continue;
    const u = urls.find((x) => re.test(x));
    if (u) faceUrl[key] = u;
  }
  const missing = Object.keys(FACE_RE).filter((k) => !faceUrl[k]);
  if (missing.length && !warnedAssets) {
    warnedAssets = true;
    ctLog(`${CT} ASSET | not found yet (placeholder used): ${missing.join(",")}`);
  }
}

// Same size as colonist's own cards (they scale with the window).
function measureCardW() {
  const img = document.querySelector("#player-card-inventory [data-card-enum] img");
  const w = img && img.getBoundingClientRect().width;
  if (w && w > 10) cardW = w;
  return cardW || Math.max(28, Math.min(60, window.innerHeight * 0.0464));
}

// -------------------------------------------------------------------- CSS ---
function injectPageStyle() {
  if (document.getElementById("ct-style")) return;
  const st = document.createElement("style");
  st.id = "ct-style";
  // Red count badge on the native panel while a player has +/- uncertainty.
  // !important beats the inline blue colonist sets, and we never touch their
  // element styles directly.
  st.textContent = `
    [data-ct-unknown="true"] [data-resource-card="true"] [class*="countBadge"] {
      background-color: #d23b3b !important;
    }`;
  document.head.appendChild(st);
}

// Tooltip look shared by all our tooltips, in colonist's own in-game tooltip
// style (its tooltipMenu: #404040, 0.25em corners, #f6f8fa text, 600 title).
const TIP_CSS = `
  .tip { display: none; position: absolute; bottom: calc(100% + 6px); left: 50%; transform: translateX(-50%);
         z-index: 50; pointer-events: none; min-width: 170px; box-sizing: border-box;
         background: #404040; color: #f6f8fa; border-radius: 3px; padding: 6px 9px;
         font: 12px/1.35 "Open Sans", sans-serif; white-space: nowrap; box-shadow: 0 2px 4px 0 rgba(0,0,0,.2); }
  .tip .tt { font-weight: 600; margin-bottom: 3px; color: #f6f8fa; }
  .tip .row { display: flex; align-items: center; gap: 8px; margin: 1px 0; font-size: .875em; }
  .tip .row span { flex: 1; }
  .tip .row b { width: 40px; text-align: right; font-weight: 600; }
  .tip .bar { width: 48px; height: 5px; background: #5a5a5a; border-radius: 3px; overflow: hidden; }
  .tip .bar i { display: block; height: 100%; background: #5d9cff; }
  .tip .tf { margin-top: 4px; color: #c8c8c8; font-size: 11px; }
`;

// Box styles. Proportions are fractions of the card width (--w), measured from
// colonist's own inventory: badge 0.498w, font 0.35w/600, radius 0.04w with one
// fully round corner, beige gradient + 0.2w padding.
const BOX_CSS = TIP_CSS + `
  .card.hint, .stack.hint { pointer-events: auto; cursor: help; }
  .card.hint:hover .tip, .card.hint.force .tip,
  .stack.hint:hover > .tip, .stack.hint.force > .tip { display: block; }
  :host { all: initial; }
  .box {
    display: flex; align-items: flex-end; box-sizing: border-box;
    padding: calc(var(--w) * 0.199);
    min-height: calc(var(--w) * 1.394 + var(--w) * 0.398);
    border-radius: calc(var(--w) * 0.0995);
    background: linear-gradient(rgb(252,250,245), rgb(226,215,196));
    box-shadow: 0 2px 10px rgba(0,0,0,.35);
    font-family: "Open Sans", sans-serif;
    user-select: none;
  }
  .stack { display: flex; position: relative; }
  /* the card to steal (rob advice, in the rob box): a simple red border round
     the stack's front card, blinking (on half the cycle, off half) */
  /* on the card's own edge and corners, painted inward over its outline; 25%
     thicker than the first (a 0.06w border drawn as 2 px at 1920 px, borders
     snap to whole pixels): 2.5 px there, as an inset shadow, which keeps the
     half pixel; then 25% thicker again: 3.1 px (0.0656w); one blink every 0.75 s
     (1 s before) (the user's calls, 2026-10-16) */
  .card.steal::after { content: ""; position: absolute; inset: 0; z-index: 40; pointer-events: none;
                        border-radius: calc(var(--w) * 0.06); box-shadow: inset 0 0 0 calc(var(--w) * 0.0656) #e3241b;
                        animation: ct-steal 0.75s step-end infinite; }
  @keyframes ct-steal { 50% { opacity: 0; } }
  /* the robber on that card (the user's call, 2026-10-16, picked on the design
     canvas): solid (only the border blinks), centred, 0.58 of the card's height,
     its base 7% above the card's bottom edge, clear of the count badge; a soft
     shadow lifts it off the card's art */
  .card img.rob { position: absolute; left: 50%; bottom: 7%; width: auto; height: 58%; border-radius: 0;
                  transform: translateX(-50%); pointer-events: none;
                  filter: drop-shadow(0 calc(var(--w) * 0.02) calc(var(--w) * 0.03) rgba(0, 0, 0, .6)); }
  /* the divider before the dev cards: colonist's own inventory partition
     (2 px on a 47.7 px card, 0.857 of the card height, centred, 3.8 px each
     side, rgba(102,102,102,.3)), scaled to this box's cards */
  .sep { flex: none; align-self: center; width: max(1px, calc(var(--w) * 0.042));
         height: calc(var(--w) * 1.394 * 0.857); margin: 0 calc(var(--w) * 0.0796);
         background: rgba(102, 102, 102, 0.3); }
  /* dev cards fan wider than resources (0.4 of each lower card shows, not 0.2),
     so a card under another is easier to see and to hover */
  .stack.devs .card + .card { margin-left: calc(var(--w) * -0.6); }
  /* suspected VP cards are set aside to the right of the other dev cards, face
     up, side by side, each with its chance in bright green above the card's
     centre, fading in by 10% steps (50% -> 0.5 ... 100% -> 1); a note under them */
  .aside { flex: none; width: calc(var(--w) * 0.3); }
  /* the note sits in the box's bottom padding, under the VP cards' right edge,
     so the box keeps its height (a taller box ran under the next row's box) */
  .vpwrap { position: relative; display: flex; }
  .vpcards, .vprow { display: flex; align-items: flex-end; }
  .vpnote { position: absolute; right: 0; top: 100%; margin-top: 1px; line-height: 1;
            color: #8a7f6a; font-size: calc(var(--w) * 0.18); white-space: nowrap; }
  .vpface + .vpface { margin-left: calc(var(--w) * 0.1); }
  .vpface img, .vpface .ph { opacity: var(--op); }
  .vpface .pc { position: absolute; left: 50%; top: 32%; transform: translate(-50%, -50%);
                font-size: calc(var(--w) * 0.3485); font-weight: 600; color: #3dff5a; white-space: nowrap;
                text-shadow: 0 0 1px #000, 0 0 2px #000, 0 0 3px #000; }
  .card { position: relative; width: var(--w); height: calc(var(--w) * 1.394); flex: none; }
  .stack .card + .card { margin-left: calc(var(--w) * -0.8); }
  .card img, .card .ph { width: 100%; height: 100%; display: block; border-radius: calc(var(--w) * 0.06); }
  .card .ph { display: flex; align-items: center; justify-content: center; color: #fff;
              font-weight: 700; font-size: calc(var(--w) * 0.5); }
  .tip .cmb { display: flex; gap: 2px; padding: 1px 0; }
  .tip .cmb img, .tip .cmb .ph { width: auto; height: 2em; aspect-ratio: 1 / 1.394; border-radius: 2px; font-size: 1em; }
  .tr {
    position: absolute; box-sizing: border-box;
    min-width: calc(var(--w) * 0.498); height: calc(var(--w) * 0.498);
    padding: 0 calc(var(--w) * 0.07);
    background: rgb(40, 95, 189); color: rgb(246, 248, 250);
    font-size: calc(var(--w) * 0.3485); font-weight: 600;
    line-height: calc(var(--w) * 0.498); text-align: center; white-space: nowrap;
  }
  .tr { top: 0; right: 1px;
        border-radius: calc(var(--w) * 0.0398) calc(var(--w) * 0.0398) calc(var(--w) * 0.0398) calc(var(--w) * 0.498); }
  .empty { color: #8a7f6a; font-size: calc(var(--w) * 0.3); padding: 0 calc(var(--w) * 0.2); align-self: center; white-space: nowrap; }
  /* opp boxes: a border in the player's colour (the user's call, 2026-10-16;
     no avatar tab), inside the padding so the box keeps its size (rows are only
     5 px apart), with the same dark rim as the framed copies */
  .box.tinted { box-shadow: inset 0 0 0 calc(var(--w) * 0.08) var(--pc), 0 0 0 1px rgba(0,0,0,.4), 0 2px 10px rgba(0,0,0,.35); }
  /* the trade box and the rob box: a thick frame around the copy (outside, no
     card covered) and a tab on its top edge, centred, with the player's avatar
     and name, both in the player's colour (--pc, text --pfg); the tab sits over
     the frame's top, so the frame skips the avatar */
  .box.framed { position: relative; --tb: 5px; }
  .box.framed::before { content: ""; position: absolute; inset: calc(-1 * var(--tb)); pointer-events: none;
                       border: var(--tb) solid var(--pc, #d23b3b); border-radius: calc(var(--w) * 0.0995 + var(--tb));
                       box-shadow: 0 0 0 1px rgba(0,0,0,.4); } /* a dark rim, like the avatars': the frame stands out on any background */
  .tag {
    position: absolute; left: 50%; bottom: 100%; transform: translateX(-50%);
    display: flex; align-items: center; gap: calc(var(--w) * 0.12);
    padding: calc(var(--w) * 0.08) calc(var(--w) * 0.22) calc(var(--w) * 0.05);
    background: var(--pc, rgb(252,250,245));
    border-radius: calc(var(--w) * 0.0995) calc(var(--w) * 0.0995) 0 0;
    box-shadow: 0 -3px 6px rgba(0,0,0,.2);
    font-size: calc(var(--w) * 0.3); font-weight: 600; color: var(--pfg, rgb(50,50,50)); white-space: nowrap;
    text-shadow: var(--pts, none);
  }
  .tag .av { width: calc(var(--w) * 0.55); height: calc(var(--w) * 0.55); border-radius: 50%;
             flex: none; background-size: cover; overflow: hidden; }
  .tag .av img { width: 100%; height: 100%; display: block; }
  /* the copy sits at the top of the screen: tooltips open below the card */
  .box.below .tip { bottom: auto; top: calc(100% + 6px); }
`;

// -------------------------------------------------------------- box markup ---
const imgTag = (key) =>
  faceUrl[key]
    ? `<img draggable="false" src="${faceUrl[key]}">`
    : `<div class="ph" style="background:${PLACEHOLDER[key]}">${PH_LETTER[key] || key[0].toUpperCase()}</div>`;

// n cards of one kind, fanned; every card shows its running count top-right
// (like colonist). Dev cards each have their own tooltip (`tips`, one per card:
// each can be a different card); any other stack has one tooltip (`tip`), shown
// wherever the stack is hovered (the user's call: its cards are alike).
function stackHtml(key, n, z, { tip = "", tips = null, steal = false } = {}) {
  let cards = "";
  for (let i = 1; i <= n; i++) {
    const own = tips && tips[i - 1] ? tips[i - 1] : "";
    const top = steal && i === n ? " steal" : ""; // the red border: the front card only
    const robber = top && pieceIcon("robber"); // and the robber standing on it
    const rob = robber ? `<img class="rob" draggable="false" src="${robber}" alt="">` : "";
    cards += `<div class="card${own ? " hint dev" : ""}${top}">${imgTag(key)}${rob}<div class="tr">${i}</div>${own}</div>`;
  }
  const cls = key === "devback" ? " devs" : tip ? " hint" : "";
  return `<div class="stack${cls}" style="z-index:${z}">${cards}${tip}</div>`;
}

// ---------------------------------------------------------------- dev tips ---
const pct = (v) => (v >= 0.01 || v === 0 ? Math.round(v * 100) + "%" : (v * 100).toFixed(1) + "%");

function pctRows(dist, minShare) {
  return Object.entries(dist)
    .filter(([, v]) => v >= minShare)
    .sort((a, b) => b[1] - a[1])
    .map(
      ([k, v]) =>
        `<div class="row"><span>${k}</span><b>${pct(v)}</b><div class="bar"><i style="width:${Math.round(v * 100)}%"></i></div></div>`
    )
    .join("");
}

// Tooltip for one face-down dev card: chance of each type + how long it was held.
function devTipHtml(c) {
  const held = `held for: ${c.held} turn${c.held === 1 ? "" : "s"}`;
  return `<div class="tip"><div class="tt">Could be</div>${pctRows(c.dist, 0.005)}<div class="tf">${held}</div></div>`;
}

const RES_LABEL = { lumber: "Lumber", brick: "Brick", wool: "Wool", grain: "Grain", ore: "Ore" };

// Tooltip for one resource stack: chance that robbing this player takes that type.
function stealTipHtml(t, p) {
  return (
    `<div class="tip"><div class="tt">Chance to steal</div>` +
    `<div class="row"><span>${RES_LABEL[t]}</span><b>${pct(p)}</b><div class="bar"><i style="width:${Math.round(p * 100)}%"></i></div></div></div>`
  );
}

// Tooltips for the "?" cards: just the rows. A card from one hidden steal that
// stands apart (unknownGroups) gets its own: the chance of each type. The others
// share one (nothing tells them apart): what they can be together, as small card
// images, the 4 most likely, then a footer with how many more there are and
// their chance in total (so the column still adds up to 100%).
const COMBOS_SHOWN = 4;
function comboRows(combos, shown) {
  const bar = (p) => `<b>${pct(p)}</b><div class="bar"><i style="width:${Math.round(p * 100)}%"></i></div>`;
  const rows = combos
    .slice(0, shown)
    .map((c) => {
      const imgs = ORDER.flatMap((t) => Array(c.cards[t] || 0).fill(imgTag(t))).join("");
      return `<div class="row"><span class="cmb">${imgs}</span>${bar(c.p)}</div>`;
    })
    .join("");
  const more = combos.slice(shown).filter((c) => c.p > 0);
  const rest = more.reduce((s, c) => s + c.p, 0);
  return rows + (more.length ? `<div class="tf">+${more.length} more (${pct(rest)})</div>` : "");
}

function groupTipHtml(g) {
  return `<div class="tip">${comboRows(g.combos, g.from ? ORDER.length : COMBOS_SHOWN)}</div>`;
}

// With the engine off: the chance of each type for one card.
function couldTipHtml(v) {
  const dist = Object.fromEntries(ORDER.map((t) => [RES_LABEL[t], v.could[t]]));
  return `<div class="tip">${pctRows(dist, 0.005)}</div>`;
}

// Certain cards as normal stacks, then one face-down card per card of unknown
// type: the ones that can only be told apart together in one stack, and each
// card from a steal that stands apart (unknownGroups) as a stack of its own.
function boxHtml(name, { steal = false } = {}) {
  const v = session.tracker.handView(name);
  const odds = session.tracker.stealOdds(name);
  const devN = Number((readPanel().find((p) => p.name === name) || {}).dev) || 0;
  let z = 20;
  let html = "";
  // In the rob box (steal), the card rob advice wants from this player gets a
  // blinking red border: on its stack, or on the "?" cards when only they can be
  // it (the user's calls, 2026-10-16: only in the rob box, not the opp box).
  const adv = steal ? currentAdvice() : null;
  const want = new Set(adv ? Object.values(adv.targets).filter((t) => t.picks[name]).map((t) => t.picks[name].res) : []);
  const stealUnknown = [...want].some((t) => !(v.sure[t] > 0));
  ORDER.forEach((t) => {
    const n = v.sure[t];
    if (n > 0) html += stackHtml(t, n, z--, { tip: odds ? stealTipHtml(t, odds[t]) : "", steal: want.has(t) });
  });
  const groups = v.unknown > 0 && session.tracker.unknownGroups(name);
  if (groups && groups.length) {
    groups.forEach((g) => (html += stackHtml("resback", g.n, z--, { tip: groupTipHtml(g), steal: stealUnknown })));
  } else if (v.unknown > 0) {
    html += stackHtml("resback", v.unknown, z--, { tip: couldTipHtml(v), steal: stealUnknown });
  }
  // Dev cards: estimates only while what we tracked agrees with colonist's own
  // count (devView); the suspected VP cards face up, set aside to the right.
  const dv = devView(name, devN);
  let note = "";
  if (devN > 0 || dv.aside.length) {
    if (html) html += '<div class="sep"></div>';
    const n = dv.rest ? dv.rest.length : dv.backs;
    if (dv.rest && n) html += stackHtml("devback", n, z--, { tips: dv.rest.map(devTipHtml) });
    else if (n) html += stackHtml("devback", n, z--, {});
    if (dv.aside.length) {
      if (n) html += '<div class="aside"></div>';
      const f = vpFacesHtml(dv.aside);
      html += f.faces;
      note = f.note;
    }
  }
  // The note under the VP cards, at the box's right (the cards stay bottom-aligned).
  if (note) html = `<div class="vpwrap"><div class="vpcards">${html}</div>${note}</div>`;
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  return html || `<div class="empty">${esc(name)}: Card Inventory Empty</div>`;
}

// ------------------------------------------------------------- tooltip log ---
// TIP lines: what one of our tooltips said when it was hovered, so a tester's
// "the box said ..." can be read back from the log (card and piece images
// written as <wool>, <settlement>...). Once per text, again after 30 s.
const tipSeen = new Map(); // where -> { text, t }
function tipText(el) {
  let out = "";
  el.childNodes.forEach((n) => {
    if (n.nodeType === Node.TEXT_NODE) out += n.textContent;
    else if (n.nodeName === "IMG") {
      const m = (n.getAttribute("src") || "").match(/\/([a-z]+)(?:_([a-z]+))?\.[0-9a-f]+\.svg/);
      out += ` <${m ? (m[1] === "card" || m[1] === "icon" ? m[2] : m[1]) : "img"}> `;
    } else out += " " + tipText(n) + " ";
  });
  return out.replace(/\s+/g, " ").trim();
}

function logTip(where, tipEl) {
  const text = tipEl ? tipText(tipEl) : "";
  if (!text) return;
  const last = tipSeen.get(where);
  if (last && last.text === text && Date.now() - last.t < 30000) return;
  tipSeen.set(where, { text, t: Date.now() });
  ctLog(`${CT} TIP | ${where} | ${text}`);
}

// A box's tooltip under the pointer: a dev card's own, or a stack's.
function logBoxTip(name, box, e) {
  for (const el of e.composedPath()) {
    if (el === box) return;
    if (!el.classList || !el.classList.contains("hint")) continue;
    const tip = [...el.children].find((c) => c.classList.contains("tip"));
    const dev = el.classList.contains("dev") ? [...box.querySelectorAll(".card.dev")].indexOf(el) + 1 : 0;
    return logTip(dev ? `${name} dev card ${dev}` : `${name} box`, tip);
  }
}

// -------------------------------------------------------------- box control ---
// Our overlays (boxes, box buttons, rob boxes, trade boxes) share one z-index, so the
// one added last paints on top. While hovered, one is raised above the rest:
// its tooltip can reach over a neighbouring box.
const Z = 2147483646;
function raiseOnHover(host, el) {
  el.addEventListener("mouseover", () => (host.style.zIndex = String(Z + 1)));
  el.addEventListener("mouseout", () => (host.style.zIndex = String(Z)));
}

function makeBox(name, attr = "data-ct-box") {
  const host = document.createElement("div");
  host.setAttribute(attr, name);
  host.style.cssText = `position:fixed;left:0;top:0;z-index:${Z};pointer-events:none;`;
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `<style>${BOX_CSS}</style><div class="box" id="box"></div>`;
  const box = shadow.getElementById("box");
  raiseOnHover(host, box);
  box.addEventListener("mouseover", (e) => logBoxTip(name, box, e));
  document.documentElement.appendChild(host);
  return { host, box, html: "" };
}

function toggleBox(name) {
  const closed = closedBoxes();
  const open = boxes.get(name);
  if (open) {
    open.host.remove();
    boxes.delete(name);
    closed.add(name);
    ctLog(`${CT} BOX | ${name} | closed`);
  } else {
    closed.delete(name);
    boxes.set(name, makeBox(name));
    ctLog(`${CT} BOX | ${name} | opened`);
  }
  saveClosedBoxes();
  updateBoxes();
}

// Every opponent's box is open by default, from the start of the game; the
// ones you close stay closed for that game, also across a reload (their names
// are kept in this tab's sessionStorage, per game: the URL hash, e.g. #city8349).
const CLOSED_KEY = "ct-closed-boxes";
const gameKey = () => location.hash || location.pathname;
let closedCache = { game: null, names: new Set() };

function closedBoxes() {
  const game = gameKey();
  if (closedCache.game !== game) {
    let saved = null;
    try {
      saved = JSON.parse(sessionStorage.getItem(CLOSED_KEY) || "null");
    } catch (e) {}
    closedCache = { game, names: new Set(saved && saved.game === game && Array.isArray(saved.names) ? saved.names : []) };
  }
  return closedCache.names;
}

function saveClosedBoxes() {
  try {
    sessionStorage.setItem(CLOSED_KEY, JSON.stringify({ game: closedCache.game, names: [...closedCache.names] }));
  } catch (e) {}
}

// Open the box of every opponent you haven't closed (not while catching up:
// the tracker is still rebuilding; not before we know which row is yours).
function openDefaultBoxes(rows) {
  const st = session && !session.catching && session.tracker.state;
  if (!st || !st.me) return;
  const closed = closedBoxes();
  const opened = rows.map(rowName).filter((n) => n && n !== st.me && !boxes.has(n) && !closed.has(n));
  if (!opened.length) return;
  opened.forEach((n) => boxes.set(n, makeBox(n)));
  ctLog(`${CT} BOX | open by default: ${opened.join(", ")}${closed.size ? ` (closed by you: ${[...closed].join(", ")})` : ""}`);
}

// ------------------------------------------------------- open/close buttons ---
// One per opponent row, centred on the left edge of its panel: the user's
// collapse/expand icon (a chevron in a circle; their 48x48 PNG measured: circle
// r 20 at 24,24, chevron tip 20,24, ends 26.75,24±6.75, 4 wide, round ends)
// redrawn as a vector in the blue of their mock-up (#2167a4), borderless, with
// a 1 px black outline around the white arrow. "<" while the box is
// open (collapse it), ">" while it is closed (open it). Size from the mock-up:
// 30 px on an 85 px panel; then the user's tweaks to the circle: 18% smaller,
// then 8% larger, with the chevron kept at its size.
const TOGGLE_SCALE = 30 / 85; // the mock-up's circle, which sets the chevron's size
const CIRCLE = 0.82 * 1.08; // the circle's diameter, as a fraction of the mock-up's (~26.6 px)
const BOX_GAP = 4; // px between a box and the button's edge
const toggles = new Map(); // player name -> { host, el, key }
const TOGGLE_CSS = `
  :host { all: initial; }
  #t { display: block; width: var(--d); height: var(--d); border-radius: 50%; cursor: pointer; pointer-events: auto; }
  #t:hover { filter: brightness(1.2); }
  svg { display: block; width: 100%; height: 100%; }
`;
// The button's (= the circle's) diameter in px.
const toggleSize = (panel) => Math.max(13, +(panel.height * TOGGLE_SCALE * CIRCLE).toFixed(2));

function toggleSvg(open, d) {
  // The viewBox is the circle (radius 20 * CIRCLE around 24,24), so the
  // chevron keeps the size it had in the mock-up's 40-unit circle.
  const R = 20 * CIRCLE;
  const u = (2 * R) / d; // viewBox units per CSS px: the arrow's outline stays 1 px at any size
  const f = (x) => +x.toFixed(3);
  const pts = open ? "26.75,17.25 20,24 26.75,30.75" : "21.25,17.25 28,24 21.25,30.75";
  const line = (color, w) =>
    `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="${f(w)}" stroke-linecap="round" stroke-linejoin="round"/>`;
  return (
    `<svg viewBox="${f(24 - R)} ${f(24 - R)} ${f(2 * R)} ${f(2 * R)}"><circle cx="24" cy="24" r="${f(R)}" fill="#2167a4"/>` +
    `${line("#000", 4 + 2 * u)}${line("#fff", 4)}</svg>`
  );
}

function updateToggles(rows) {
  const st = session && !session.catching && session.tracker.state;
  const want = new Set();
  for (const row of st && st.me ? rows : []) {
    const name = rowName(row);
    const info = row.querySelector('[class*="playerInformation"]');
    if (!name || name === st.me || !info) continue;
    const r = info.getBoundingClientRect();
    if (!r.width || !r.height) continue;
    want.add(name);
    let t = toggles.get(name);
    if (!t) {
      const host = document.createElement("div");
      host.setAttribute("data-ct-toggle", name);
      host.style.cssText = `position:fixed;left:0;top:0;z-index:${Z};pointer-events:none;`;
      const shadow = host.attachShadow({ mode: "open" });
      shadow.innerHTML = `<style>${TOGGLE_CSS}</style><div id="t" role="button"></div>`;
      const el = shadow.getElementById("t");
      el.addEventListener("click", () => toggleBox(name));
      document.documentElement.appendChild(host);
      t = { host, el, key: "" };
      toggles.set(name, t);
    }
    const d = toggleSize(r);
    const open = boxes.has(name);
    const key = `${open}|${d}`;
    if (key !== t.key) {
      t.key = key;
      t.el.style.setProperty("--d", `${d}px`);
      t.el.innerHTML = toggleSvg(open, d);
    }
    t.host.style.transform = `translate(${Math.round(r.left - d / 2)}px, ${Math.round(r.top + (r.height - d) / 2)}px)`;
  }
  for (const [n, t] of toggles) {
    if (!want.has(n)) {
      t.host.remove();
      toggles.delete(n);
    }
  }
}

// ------------------------------------------------------ trade offer copies ---
// While an opponent's trade offer is open, a full-size copy of their box sits
// just outside the offer window's left edge,
// vertically centred on the offerer's avatar at the left of the window's top
// card row (the cards you would get), with a thick frame and a tab on its top
// edge carrying the offerer's avatar and name (the frame skips the tab), both in
// the offerer's own colour (their avatar's, as in the panel and the offer
// window). When the offer opens, the copy flies out of the offerer's own box
// (from the spot beside their row, fading in, when that box is closed) to the
// window in FLY_MS, and flies back into it, fading out, when the offer closes:
// the user's pick (2026-10-15) to show whose offer it is. Their own box stays
// where it is, unchanged (after a grayed-out and then a hidden original). The
// copy shows even if that box is closed. Not for your own offers (the user's call).
// Offer windows: [class*="gameTradeOffersWrapper"] inside colonist's
// gameTradeOffersContainer, present only while an offer is shown (found with
// probes/trade-dom.js). The offerer is matched to a panel row by the avatar's
// colour class; your own offer has a colourless group icon there instead.
const tradeCopies = new Map(); // player name -> { host, box, html }
const TRADE_GAP = 6; // px between a copy's frame and the offer window
const TRADE_FRAME = 5; // the frame's width (--tb in BOX_CSS), drawn outside the box
const FLY_MS = 500; // a copy's flight between the offerer's box and the offer window
const TRADE_SCALE = 1; // the copy's size vs the regular box (the user's call: full size; tried ~0.5, then 0.75)
let tradeKey = "";

// Open opponent offers: player name -> { av, win } (offerer's avatar, window).
function openOffers() {
  const me = session.tracker.state.me;
  const byColor = new Map(panelRows().map((r) => [avatarColor(r), rowName(r)]));
  const out = new Map();
  for (const win of document.querySelectorAll('div[class*="gameTradeOffersWrapper"]')) {
    const av = win.querySelector('[class*="receivingHalfContainer"] [class*="leftContainer"] div[class*="avatar"]');
    const color = av && avatarColor(av);
    const name = color && byColor.get(color);
    if (!name || name === me || out.has(name)) continue;
    const r = av.getBoundingClientRect();
    if (r.width && r.height) out.set(name, { av, win });
  }
  for (const name of tradeDemo) {
    const row = panelRows().find((r) => rowName(r) === name);
    const av = row && row.querySelector('[class*="avatarAndPoints"] div[class*="avatar"]');
    if (av && !out.has(name)) out.set(name, { av, win: null });
  }
  return out;
}

// Debug (no game input): "ct-trade-demo" (detail = name) fakes an open offer
// from that player (the copy flies to a spot on the board); again to close it.
const tradeDemo = new Set();
document.addEventListener("ct-trade-demo", (e) => {
  const n = String(e.detail);
  if (tradeDemo.has(n)) tradeDemo.delete(n);
  else tradeDemo.add(n);
  if (session) updateBoxes();
});

// The offerer's colour, from an avatar's gradient: colonist draws each avatar
// as a coloured disk, a white ring and a dark rim, so it is the stop just inside
// the ring (Heath's blue rgb(33, 91, 190), red rgb(236, 33, 40)...). Text on it:
// white with a soft shadow, or colonist's dark grey on a light colour.
function playerColour(av) {
  const stops = [...getComputedStyle(av).backgroundImage.matchAll(/rgba?\((\d+), (\d+), (\d+)/g)].map((m) => [+m[1], +m[2], +m[3]]);
  const ring = stops.findIndex((c, i) => i > 0 && c.every((v) => v === 255));
  const c = stops[ring > 0 ? ring - 1 : Math.floor(stops.length / 2)];
  if (!c) return null;
  const lum = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  return lum > 0.6
    ? { bg: `rgb(${c.join(", ")})`, fg: "rgb(50, 50, 50)", shadow: "none" }
    : { bg: `rgb(${c.join(", ")})`, fg: "#fff", shadow: "0 1px 2px rgba(0, 0, 0, .45)" };
}

// Where a copy flies out of and back into: the player's own box while it is
// open (shown), else the spot left of their row where that box would sit. The
// spot is the box's; a rob box's host also holds the robber left of the box, so
// hosts are placed by hostAt (c.dx, c.dy = the box's offset in its host).
function tradeHome(n, c) {
  const b = boxes.get(n);
  if (b && b.host.style.display !== "none") {
    const r = b.box.getBoundingClientRect();
    if (r.width) return { left: r.left, top: r.top, shown: true };
  }
  const row = panelRows().find((r) => rowName(r) === n);
  const info = row && (row.querySelector('[class*="playerInformation"]') || row);
  if (!info) return null;
  const r = info.getBoundingClientRect();
  return { left: r.left - toggleSize(r) / 2 - BOX_GAP - c.box.offsetWidth, top: r.top, shown: false };
}

const hostAt = (c, left, top) => `translate(${Math.round(left - (c.dx || 0))}px, ${Math.round(top - (c.dy || 0))}px)`;

function flyHome(n, c) {
  const home = tradeHome(n, c);
  c.host.style.transition = `transform ${FLY_MS}ms cubic-bezier(.5, 0, .75, 0), opacity ${FLY_MS}ms ease-in`;
  if (home) c.host.style.transform = hostAt(c, home.left, home.top);
  c.host.style.opacity = "0";
  setTimeout(() => c.host.remove(), FLY_MS + 50);
}

// The copy's name tab: the offer window's own avatar (its colour gradient and
// icon, read from the page) and the player's name.
function tagHtml(name, av) {
  const cs = getComputedStyle(av);
  const img = av.querySelector("img");
  const css = (s) => String(s).replace(/"/g, "'");
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const bg = `background-color:${css(cs.backgroundColor)};background-image:${css(cs.backgroundImage)}`;
  return (
    `<div class="tag"><span class="av" style="${bg}">${img ? `<img draggable="false" src="${esc(img.src)}">` : ""}</span>` +
    `<span>${esc(name)}</span></div>`
  );
}

function updateTradeCopies() {
  const offers = session.catching ? new Map() : openOffers();
  for (const [n, c] of tradeCopies) {
    if (!offers.has(n)) {
      tradeCopies.delete(n);
      flyHome(n, c);
    }
  }
  for (const [n, { av, win }] of offers) {
    let c = tradeCopies.get(n);
    const fresh = !c;
    if (fresh) {
      c = makeBox(n, "data-ct-trade-box");
      c.box.classList.add("below", "framed");
      tradeCopies.set(n, c);
    }
    const a = av.getBoundingClientRect();
    const cw = +(measureCardW() * TRADE_SCALE).toFixed(2);
    const html = boxHtml(n) + tagHtml(n, av);
    const key = `${cw}|${html}`;
    if (c.html !== key) {
      c.html = key;
      c.box.style.setProperty("--w", `${cw}px`);
      c.box.innerHTML = html;
      const pc = playerColour(av);
      if (pc) {
        c.box.style.setProperty("--pc", pc.bg);
        c.box.style.setProperty("--pfg", pc.fg);
        c.box.style.setProperty("--pts", pc.shadow);
      }
    }
    const left = win
      ? Math.max(8, win.getBoundingClientRect().left - TRADE_GAP - TRADE_FRAME - c.box.offsetWidth)
      : Math.round(window.innerWidth * 0.42 - c.box.offsetWidth); // demo: a spot on the board
    const top = win ? a.top + (a.height - c.box.offsetHeight) / 2 : 150;
    if (fresh) {
      // Start on the offerer's own box (or beside their row, invisible), then fly.
      const home = tradeHome(n, c);
      c.host.style.transition = "none";
      c.host.style.opacity = home && home.shown ? "1" : "0";
      if (home) c.host.style.transform = `translate(${Math.round(home.left)}px, ${Math.round(home.top)}px)`;
      void c.host.offsetWidth;
      c.host.style.transition = `transform ${FLY_MS}ms cubic-bezier(.2, .8, .2, 1), opacity ${FLY_MS}ms ease-out`;
      c.host.style.opacity = "1";
    }
    c.host.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
  }
  const key = [...offers.keys()].join(", ");
  if (key !== tradeKey) {
    tradeKey = key;
    ctLog(`${CT} TRADE | ${key ? `offer open from ${key}: box copy flies to the offer (frame + tab in their colour), original stays` : "no offer open"}`);
  }
}

// ------------------------------------------------------- deck odds tooltip ---
let deckTip = null; // { host, tip, btn, html }
let deckTipForced = false; // debug: keep it open without hovering

function deckTipHtml() {
  const tr = session.tracker;
  const est = tr.devEstimate();
  const d = est.deck;
  const me = tr.state.me;
  const myHeld = me && tr.state.players[me] ? tr.state.players[me].devCards.length : 0;
  let body;
  if (d.size <= 0) body = '<div class="tf">The deck is empty.</div>';
  else {
    body =
      pctRows(d.chance, 0.0005) +
      `<div class="tf">${d.size} card${d.size === 1 ? "" : "s"} left in the deck</div>` +
      (!est.ownKnown && myHeld > 0
        ? '<div class="tf">Your own cards are not read yet, so these odds are rougher.</div>'
        : "");
  }
  return `<div class="tt">Next development card</div>${body}`;
}

function showDeckTip(btn) {
  if (!session) return;
  if (!deckTip) {
    const host = document.createElement("div");
    host.setAttribute("data-ct-decktip", "");
    host.style.cssText = "position:fixed;left:0;top:0;z-index:2147483647;pointer-events:none;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>${TIP_CSS} .tip { display: block; position: static; transform: none; }</style><div class="tip" id="tip"></div>`;
    document.documentElement.appendChild(host);
    deckTip = { host, tip: shadow.getElementById("tip"), btn, html: "" };
  }
  deckTip.btn = btn;
  refreshDeckTip();
  if (deckTip) logTip("deck (buy button)", deckTip.tip);
}

function refreshDeckTip() {
  if (!deckTip) return;
  const btn = document.querySelector("#action-button-buy-dev-card");
  if (!btn || !session) return hideDeckTip();
  const html = deckTipHtml();
  if (html !== deckTip.html) {
    deckTip.html = html;
    deckTip.tip.innerHTML = html;
  }
  const r = btn.getBoundingClientRect();
  const w = deckTip.tip.offsetWidth;
  const h = deckTip.tip.offsetHeight;
  const left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left + r.width / 2 - w / 2));
  const top = Math.max(8, r.top - h - 10);
  deckTip.host.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
}

function hideDeckTip() {
  if (deckTip) deckTip.host.remove();
  deckTip = null;
}

document.addEventListener(
  "mouseover",
  (e) => {
    const btn = e.target.closest && e.target.closest("#action-button-buy-dev-card");
    if (btn) showDeckTip(btn);
  },
  true
);
document.addEventListener(
  "mouseout",
  (e) => {
    const btn = e.target.closest && e.target.closest("#action-button-buy-dev-card");
    if (btn && !deckTipForced && !(e.relatedTarget && btn.contains(e.relatedTarget))) hideDeckTip();
  },
  true
);
// Debug/verification hooks (no game input), via document.dispatchEvent(new CustomEvent(...)):
//   "ct-deck-tip"  toggles the deck odds tooltip open
//   "ct-force-tip" with detail "Name" opens the tooltip of that box's last dev card
document.addEventListener("ct-deck-tip", () => {
  deckTipForced = !deckTipForced;
  if (deckTipForced) showDeckTip(document.querySelector("#action-button-buy-dev-card"));
  else hideDeckTip();
});
document.addEventListener("ct-force-tip", (e) => {
  const b = boxes.get(String(e.detail));
  const card = b && [...b.box.querySelectorAll(".card.dev")].pop();
  if (card) card.classList.toggle("force");
});
//   "ct-force-steal-tip" with detail "Name" opens the steal tooltip of that box's first resource stack
document.addEventListener("ct-force-steal-tip", (e) => {
  const b = boxes.get(String(e.detail));
  const stack = b && b.box.querySelector(".stack.hint");
  if (stack) stack.classList.toggle("force");
});

// While it is your turn and you have not rolled yet, colonist shows its dice
// for you to click (bottom right of the board), and an open box can cover
// them. Then every box over the dice slides to their left (fully visible),
// and back after the roll. The trigger is the tracker's own turn state (turn
// marker + log), not a dice class. Before the game's first roll: only once
// setup is over (2 settlements and 2 roads each: tracker setupDone()).
let diceWaiting = false;
let diceDemo = false; // debug: act as if you had to roll ("ct-dice-demo")

function awaitingMyRoll() {
  if (diceDemo) return true;
  const st = session && !session.catching && session.tracker.state;
  if (!st || !st.me || st.currentPlayer !== st.me || st.lastRoller === st.me) return false;
  // Before the game's first roll: only once every setup road is down (the user's
  // bug report: the boxes slid while they still had to place their second road).
  return session.tracker.setupDone();
}

// The board's dice: a diceGroup outside the player panel (each panel row has a
// hidden one of its own), the largest if several. null if not found.
function boardDiceRect() {
  const rects = [...document.querySelectorAll('div[class*="diceGroup"]')]
    .filter((el) => !el.closest('[data-player-information-container="true"]'))
    .map((el) => el.getBoundingClientRect())
    .filter((r) => r.width > 0 && r.height > 0)
    .sort((a, b) => b.width * b.height - a.width * a.height);
  return rects[0] || null;
}

const overlaps = (a, b) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;

// Place each box left of its row's visible part, clear of the row's open/close
// button, top-aligned with it.
function updateBoxes() {
  if (!session) return;
  refreshDeckTip();
  harvestAssets();
  const w = measureCardW();
  const rows = panelRows();
  openDefaultBoxes(rows);
  updateToggles(rows);
  const rowsByName = new Map(rows.map((r) => [rowName(r), r]));
  const waiting = awaitingMyRoll();
  const dice = waiting ? boardDiceRect() : null;
  if (waiting !== diceWaiting) {
    diceWaiting = waiting;
    const imgs = [...document.querySelectorAll('div[class*="diceGroup"] img[class*="dice-"]')]
      .filter((el) => !el.closest('[data-player-information-container="true"]'))
      .map((el) => el.className)
      .join(" / ");
    ctLog(`${CT} DICE | ${waiting ? `your roll: boxes over the dice slide aside (dice ${dice ? "found" : "not found"}; classes: ${imgs || "none"})` : "rolled: boxes back"}`);
  }
  for (const [name, b] of boxes) {
    const row = rowsByName.get(name);
    if (!row) {
      b.host.style.display = "none";
      continue;
    }
    b.host.style.display = "";
    // Console: the cards an open box shows, whenever they change (tooltips aside).
    const v = session.tracker.handView(name);
    const could = ORDER.filter((t) => v.could[t] >= 0.005).map((t) => `${t} ${pct(v.could[t])}`).join(" ");
    const shown =
      ORDER.filter((t) => v.sure[t])
        .map((t) => `${t} ${v.sure[t]}`)
        .concat(v.unknown ? [`? ${v.unknown}${could ? ` (each: ${could})` : ""}`] : [])
        .join(", ") || "no cards";
    if (shown !== b.shown) {
      b.shown = shown;
      ctLog(`${CT} BOX | ${name} | ${shown}`);
    }
    const html = boxHtml(name);
    const key = `${w}|${html}`;
    if (b.html !== key) {
      b.html = key;
      b.box.style.setProperty("--w", `${w}px`);
      b.box.innerHTML = html;
    }
    // The border in their colour (their panel avatar's, as the trade box's frame).
    if (!b.pc) {
      const av = row.querySelector('[class*="avatarAndPoints"] div[class*="avatar"]');
      const pc = av && playerColour(av);
      if (pc) {
        b.pc = pc.bg;
        b.box.style.setProperty("--pc", pc.bg);
        b.box.classList.add("tinted");
      }
    }
    // The row also contains a hidden dice group on its left; use the visible part.
    const anchor = row.querySelector('[class*="playerInformation"]') || row;
    const r = anchor.getBoundingClientRect();
    const bw = b.box.offsetWidth;
    const bh = b.box.offsetHeight;
    let left = Math.max(8, r.left - toggleSize(r) / 2 - BOX_GAP - bw);
    const top = Math.max(8, Math.min(r.top, window.innerHeight - bh - 8));
    // Your roll: a box over the dice slides to their left.
    if (dice && overlaps({ left, top, right: left + bw, bottom: top + bh }, dice)) left = Math.max(8, dice.left - 8 - bw);
    b.host.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
    // Animate moves from the second placement on (not the jump from 0,0 on opening).
    if (!b.placed) {
      b.placed = true;
      setTimeout(() => (b.host.style.transition = "transform .25s ease-out"), 50);
    }
  }
  updateTradeCopies();
  updateRobBoxes();
  updateVpMarks();
  if (!session.catching) logDevs();
}

// DEVS: every opponent's face-down dev cards with the odds their tooltips show
// (and colonist's count when it differs from ours); DECK: the next card's odds.
// Logged whenever a rounded percentage changes.
const DEV_SHORT = { Knight: "K", "Victory Point": "VP", "Road Building": "RB", "Year of Plenty": "YoP", Monopoly: "Mono" };
const devFmt = (dist) =>
  Object.entries(dist)
    .filter(([, p]) => p >= 0.005)
    .sort((a, b) => b[1] - a[1])
    .map(([t, p]) => `${DEV_SHORT[t] || t} ${Math.round(p * 100)}%`)
    .join(" ");
function logDevs() {
  const est = session.tracker.devEstimate();
  const me = session.tracker.state.me;
  const panel = new Map(readPanel().map((p) => [p.name, Number(p.dev) || 0]));
  const parts = [];
  for (const [n, cards] of Object.entries(est.cards || {})) {
    if (n === me || !cards || !cards.length) continue;
    const off = panel.has(n) && panel.get(n) !== cards.length ? ` [colonist shows ${panel.get(n)}]` : "";
    parts.push(`${n}: ${cards.map((c) => `#${c.id} ${devFmt(c.dist)} held ${c.held}`).join(", ")}${off}`);
  }
  const devs = parts.join(" | ") || "no opponent holds a dev card";
  if (devs !== session.devsKey) {
    session.devsKey = devs;
    ctLog(`${CT} DEVS | ${devs}`);
  }
  const d = est.deck;
  const deck = d.size > 0 ? `${d.size} left | ${devFmt(d.chance)}` : "empty";
  if (deck !== session.deckKey) {
    session.deckKey = deck;
    ctLog(`${CT} DECK | ${deck}`);
  }
}

// ------------------------------------------------------- suspected VP cards ---
// The user's design (2026-10-15, reworked 2026-10-16), per opponent, for the
// held dev cards meeting the "50% condition" (vpSuspects: VP at least 50%, no
// other type above 25%):
//  - In their inventory box those cards turn face up by themselves, set aside
//    to the right of the other dev cards, side by side: colonist's VP card, its
//    chance in bright green above the card's centre, the card fading in by 10%
//    steps (50% -> 0.5 ... 100% -> 1), each keeping its own tooltip, with a
//    small note "(+VP) at 90%" under them (vpFacesHtml). Nothing to click: the
//    user's call, 2026-10-16, which removed the VP card and info symbol from
//    the panel (with their blink, hover box and pin).
//  - Ribbon: "4 (7)" once a card is at VP_SURE (90%): colonist's VP number plus
//    those cards, drawn whole by us in colonist's font and colour but smaller, to
//    fit the ribbon's flat middle, with a narrow gap, centred like colonist's own
//    numbers (the user's exception to "same size", 2026-10-15); colonist's own
//    number is hidden meanwhile.
// Only while the tracked held cards match colonist's dev count (like the box's
// dev tooltips). At a buy colonist's count moves a few seconds before the log
// row, so the last matching view stays for VP_GRACE (devView) instead of the
// cards flipping back for a moment. Elements (read-only probe
// probes/avatar-points.js, 2026-10-15): the number
// [class*="victoryPointsContainer"] > span over img ribbon_small.
const vpMarks = new Map(); // name -> { ribHost, rib, span, ribText, ribSize, key } (the ribbon, see makeVpMark)
const VP_GRACE = 5000; // ms the last matching view stays while colonist's dev count and ours differ

// Debug (no game input): "ct-vp-demo" with detail "Name|0.54,0.93" adds fake
// suspected cards with those chances to that player's box and ribbon; the same
// name again removes them.
const vpDemo = new Map();
document.addEventListener("ct-vp-demo", (e) => {
  const [name, list] = String(e.detail).split("|");
  if (vpDemo.has(name)) vpDemo.delete(name);
  else {
    const cards = String(list || "0.5")
      .split(",")
      .map((p, k) => {
        const v = Number(p) || 0.5;
        return { id: `demo${k}`, p: v, held: 0, dist: { "Victory Point": v, Knight: +(1 - v).toFixed(4) } };
      });
    vpDemo.set(name, cards);
  }
  if (session) updateBoxes();
});

const VP_CSS = `
  :host { all: initial; }
  #rib { white-space: nowrap; }
  #rib .g { display: inline-block; width: 0.14em; } /* the gap in "4 (7)": about half a space */
`;

const vpStep = (p) => Math.min(10, Math.floor(Math.round(p * 100) / 10)); // 10% step as the tooltips round it
const vpSurePct = () => Math.round(((typeof TrackerCore !== "undefined" && TrackerCore.VP_SURE) || 0.9) * 100);

function overlayHost(attr, name, css, inner, z = Z) {
  const host = document.createElement("div");
  host.setAttribute(attr, name);
  host.style.cssText = `position:fixed;left:0;top:0;z-index:${z};pointer-events:none;`;
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `<style>${css}</style>${inner}`;
  document.documentElement.appendChild(host);
  return { host, shadow };
}

// A player's dev cards as their box shows them: { rest, aside, backs }. rest =
// the face-down cards with their odds (tracker entries), aside = the suspected
// VP cards (entries plus p, their VP chance); while our count differs from
// colonist's, the last matching view for VP_GRACE, then rest = null and
// `backs` plain card backs.
const devViewLast = new Map(); // name -> { v, t }
function devView(name, devN) {
  const cards = session.tracker.devEstimate().cards[name];
  let v;
  if (cards && cards.length === devN) {
    const vp = new Set(((session.tracker.vpSuspects(name) || {}).cards || []).map((c) => c.i));
    v = {
      rest: cards.filter((c, i) => !vp.has(i)),
      aside: cards.filter((c, i) => vp.has(i)).map((c) => ({ ...c, p: c.dist["Victory Point"] })),
      backs: 0,
    };
    devViewLast.set(name, { v, t: Date.now() });
  } else {
    const last = devViewLast.get(name);
    v = last && Date.now() - last.t < VP_GRACE ? last.v : { rest: null, aside: [], backs: devN };
  }
  const demo = vpDemo.get(name);
  return demo ? { ...v, aside: [...v.aside, ...demo] } : v;
}

// The suspected VP cards in a box: face up, side by side, with their chances,
// and the note that goes under them.
function vpFacesHtml(cards) {
  const url = vpCardUrl();
  const faces = cards
    .map((c) => {
      const face = url ? `<img draggable="false" src="${url}">` : `<div class="ph" style="background:#6d4aa8">VP</div>`;
      return `<div class="card vpface hint dev" style="--op:${Math.max(5, vpStep(c.p)) / 10}">${face}<div class="pc">${pct(c.p)}</div>${devTipHtml(c)}</div>`;
    })
    .join("");
  return { faces: `<div class="vprow">${faces}</div>`, note: `<div class="vpnote">(+VP) at ${vpSurePct()}%</div>` };
}

// The ribbon's overlay for one player.
function makeVpMark(name) {
  const rib = overlayHost("data-ct-vp-ribbon", name, VP_CSS, `<div id="rib"></div>`);
  return { ribHost: rib.host, rib: rib.shadow.getElementById("rib"), span: null, ribText: "", key: "" };
}

function removeVpMark(m) {
  if (m.span) m.span.style.visibility = "";
  m.ribHost.remove();
}

function updateVpMarks() {
  const me = session.tracker.state.me;
  const want = new Map();
  if (!session.catching) {
    for (const row of panelRows()) {
      const name = rowName(row);
      if (!name || name === me) continue;
      const devN = Number(row.querySelector('[data-development-card="true"] [class*="count-"]')?.textContent.trim()) || 0;
      const cards = devView(name, devN).aside;
      if (cards.length) want.set(name, { row, s: { cards, sure: cards.filter((c) => Math.round(c.p * 100) >= vpSurePct()).length } });
    }
  }
  for (const [n, m] of vpMarks) {
    if (!want.has(n)) {
      removeVpMark(m);
      vpMarks.delete(n);
    }
  }
  for (const [n, { row, s }] of want) {
    let m = vpMarks.get(n);
    if (!m) vpMarks.set(n, (m = makeVpMark(n)));
    const key = s.cards.map((c) => `${c.id}@${vpStep(c.p)}`).join(" ") + ` sure ${s.sure}`;
    if (key !== m.key) {
      m.key = key;
      const list = s.cards.map((c) => `card ${c.id} ${pct(c.p)} (held ${c.held})`).join(", ");
      ctLog(`${CT} VP | ${n}: ${list}${s.sure ? ` | ${s.sure} at 90%+` : ""}`);
    }

    // The ribbon: "4 (7)" from the first card at 90%, drawn whole, sized to the
    // ribbon's flat middle (its tails are ~20% of its width each side).
    const span = row.querySelector('[class*="victoryPointsContainer"] span');
    const ribbon = row.querySelector('[class*="victoryPointsContainer"] img');
    const vp = span ? parseInt(span.textContent, 10) : NaN;
    if (m.span && m.span !== span) m.span.style.visibility = "";
    m.span = span;
    if (!span || !s.sure || !Number.isFinite(vp)) {
      if (span) span.style.visibility = "";
      m.ribHost.style.display = "none";
      continue;
    }
    const cs = getComputedStyle(span);
    const rb = (ribbon || span).getBoundingClientRect();
    const base = parseFloat(cs.fontSize);
    const html = `${vp}<span class="g"></span>(${vp + s.sure})`;
    const font = `font-family:${cs.fontFamily.replace(/"/g, "'")};font-weight:${cs.fontWeight};color:${cs.color}`;
    const ribKey = `${html}|${font}|${base}|${Math.round(rb.width)}`;
    m.ribHost.style.display = "";
    if (ribKey !== m.ribText) {
      m.ribText = ribKey;
      m.rib.innerHTML = html;
      m.rib.style.cssText = `${font};font-size:${base}px;line-height:normal`;
      const size = Math.max(8, Math.min(base, (base * rb.width * 0.56) / m.rib.offsetWidth));
      m.rib.style.fontSize = `${size.toFixed(1)}px`;
      m.ribSize = size;
    }
    span.style.visibility = "hidden";
    // Centred like colonist's own numbers: across, on the ribbon's middle; down,
    // the digits' middle (font metrics) where colonist's digits have theirs.
    const fm = digitMetrics(cs.fontWeight, cs.fontFamily);
    // Colonist's text box (a range over its text: the span itself is taller, its
    // text top-aligned), then its digits' middle from the font's metrics.
    const range = document.createRange();
    range.selectNodeContents(span);
    const tr = range.getBoundingClientRect();
    const sr = tr.height ? tr : span.getBoundingClientRect();
    const inkMid = sr.top + (sr.height - (fm.fa + fm.fd) * base) / 2 + (fm.fa - (fm.ia - fm.id) / 2) * base;
    const ourInk = (m.rib.offsetHeight - (fm.fa + fm.fd) * m.ribSize) / 2 + (fm.fa - (fm.ia - fm.id) / 2) * m.ribSize;
    const x = rb.left + rb.width / 2 - m.rib.offsetWidth / 2;
    m.ribHost.style.transform = `translate(${x.toFixed(1)}px, ${(inkMid - ourInk).toFixed(1)}px)`;
  }
}

// A font's line box and digit ink per px of font size (canvas measureText, the
// same font as the page's): fa/fd = ascent/descent of the line, ia/id = how far
// the digits' ink reaches above/below the baseline.
const digitCache = new Map();
function digitMetrics(weight, family) {
  const key = `${weight} ${family}`;
  if (!digitCache.has(key)) {
    const ctx = document.createElement("canvas").getContext("2d");
    ctx.font = `${weight} 100px ${family}`;
    const m = ctx.measureText("0123456789");
    digitCache.set(key, {
      fa: m.fontBoundingBoxAscent / 100,
      fd: m.fontBoundingBoxDescent / 100,
      ia: m.actualBoundingBoxAscent / 100,
      id: m.actualBoundingBoxDescent / 100,
    });
  }
  return digitCache.get(key);
}

function closeAllBoxes() {
  boxes.forEach((b) => b.host.remove());
  boxes.clear();
  tradeCopies.forEach((c) => c.host.remove());
  tradeCopies.clear();
  vpMarks.forEach(removeVpMark);
  vpMarks.clear();
  tradeKey = "";
  toggles.forEach((t) => t.host.remove());
  toggles.clear();
}

// Red card-count badge on the native panel while a player has +/- markers.
function markRows() {
  if (!session) return;
  const me = session.tracker.state.me;
  panelRows().forEach((row) => {
    const name = rowName(row);
    const flag = name && name !== me && session.tracker.inspect(name).uncertain;
    if (flag) row.setAttribute("data-ct-unknown", "true");
    else row.removeAttribute("data-ct-unknown");
  });
}

// ------------------------------------------------------------------ rob box ---
// On your turn, when you can move the robber (you rolled a 7 and have not moved
// it yet, or you hold a Knight you may play) and you are one card short of a
// settlement or a city you still have a piece for (robAdvice), the opponent with
// the best chance (at least 1 in 3, ROB_MIN) of giving you that card gets a rob
// box (the user's design, 2026-10-16, "like the trade box"): a full-size copy of
// their opp box with the frame and the avatar/name tab in their colour, flying
// out of their opp box (fading in from beside their row when it's closed) and
// back when the advice ends. It stacks above your inventory strip, from its left
// edge (my call: that's where you look to play a Knight, it stays off the board
// you click to move the robber, and away from the trade box at the top right);
// two targets stack upward. The card to steal has a blinking red border (rob
// box only) with the robber standing on it, solid. Right of the rob box, close
// to its frame, its advice (the odds, the card, the piece it completes, a bank
// trade with its port badge), always open (the user's calls, 2026-10-16: option
// B, "slim advice", of the design canvas; nothing in the panel). While the
// advice comes from a playable Knight, your Knight
// cards in the strip get a soft golden glow (updateKnightGlow). Icons are
// colonist's own assets (icon_robber, settlement_<colour>, city_<colour>; the
// pieces in the tooltip are in your colour, read from your avatar's class:
// PLAYER COLOR in content_old.js).
const COLORS = ["black", "blue", "bronze", "gold", "green", "mysticblue", "orange", "pink", "purple", "red", "silver", "white"];
const robBoxes = new Map(); // target name -> { host, wrap, box, tip, html, tipHtml, dx, dy }
const pieceUrl = {};
let robKey = "";
let robDemo = null; // debug: fake advice so the rob boxes can be checked on screen
const ROB_GAP = 12; // px between a rob box's frame and the strip under it, or the rob box under it
// The port badge's symbols all get the same area, whatever their shape (portBadge).
const BADGE_AREA = 196; // px², a 14 px square: brick 18.7 x 10.5, grain 13.4 x 14.6, the bank 14 x 14
const BADGE_W = 20; // the badge unit's width (the widest symbol, brick, and "4:1" fit)
const BADGE_SLOT = 15; // the symbol slot's height (the tallest symbol, grain, fits)
// The rob box host: a framed copy of the opp box, then its advice on its right.
// BOX_CSS for the box; the advice's rules are scoped to .say, so the box's own
// tooltips keep theirs.
const ROB_CSS = BOX_CSS + `
  .rb { position: relative; display: flex; align-items: center; }
  /* the advice: always open, right of the rob box, centred on it, close to its
     frame (TRADE_FRAME + 10 px); colonist's tooltip look (#404040, light text),
     no % bar, no tail; option B of the design canvas (the user's pick,
     2026-10-16): about half the old size, each fact once */
  .say { flex: none; margin-left: calc(var(--frame) + 10px); background: #404040; color: #f6f8fa;
         border-radius: 3px; padding: 5px 8px 6px; font: 600 12px/1.3 "Open Sans", sans-serif; white-space: nowrap;
         box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .2); pointer-events: none; }
  .say.shut { display: none; }
  .say .ln { display: flex; align-items: center; gap: 5px; }
  .say .ln + .ln { margin-top: 5px; padding-top: 5px; border-top: 1px solid rgba(255, 255, 255, .14); }
  .say .odds b { font-size: 17px; font-weight: 800; letter-spacing: -0.2px; min-width: 44px; }
  .say .arw { color: #bdbdbd; font-weight: 700; }
  .say .ci { height: 20px; width: auto; display: block; border-radius: 2px; }
  .say span.ci { aspect-ratio: 1 / 1.394; }
  /* the piece on a light chip: your colour's piece can be black, lost on #404040 */
  .say .chip { width: 24px; height: 24px; border-radius: 50%; background: #f6f8fa; flex: none;
               display: flex; align-items: center; justify-content: center; }
  .say .chip img { width: 17px; height: 17px; display: block; }
  .say .chip b { color: #404040; font-size: 11px; font-weight: 800; }
  /* the trade line: the port badge, "4×" the cards given, the card taken */
  .say .trade { gap: 3px; font-size: 11px; color: #d0d0d0; }
  .say .trade .ci { height: 16px; }
  .say .trade .n { font-weight: 800; color: #f6f8fa; }
  /* the port badge: one fixed unit (the user's call, 2026-10-16), the same size
     and spot for every type: the symbol centred in a BADGE_W x BADGE_SLOT slot,
     sized by portBadge to the same area whatever its shape, the rate under it */
  .say .port { flex: none; display: flex; flex-direction: column; align-items: center; width: ${BADGE_W}px; margin-right: 3px; }
  .say .port .sym { height: ${BADGE_SLOT}px; width: 100%; display: flex; align-items: center; justify-content: center; }
  .say .port img { display: block; }
  .say .port .q { font: 800 19px/${BADGE_SLOT}px "Open Sans", sans-serif; color: #f6f8fa; } /* ink ~14 px tall, as the bank */
  .say .port i { font: 800 9px/1 "Open Sans", sans-serif; font-style: normal; color: #f6f8fa; margin-top: 1px; }
`;

// A player's colour, from an avatar's colour class (e.g. "red-x1y2z3w4"): the
// element itself or an avatar inside it (a panel row, a trade window avatar).
function avatarColor(root) {
  for (const el of [root, ...root.querySelectorAll('[class*="avatar"]')]) {
    for (const c of el.classList) {
      const m = c.match(/^([a-z]+)-/);
      if (m && COLORS.includes(m[1])) return m[1];
    }
  }
  return null;
}

function myColor() {
  const me = session && session.tracker.state.me;
  const row = panelRows().find((r) => rowName(r) === me);
  return row ? avatarColor(row) : null;
}

function findAsset(re) {
  return (
    [...document.images].map((i) => i.src).find((u) => re.test(u)) ||
    performance.getEntriesByType("resource").map((r) => r.name).find((u) => re.test(u))
  );
}

// The robber icon only loads once the robber has moved, the VP card only once
// someone holds one. Until then, read their hashed file names from colonist's
// own JS bundle (one fetch, normally cached).
let robberLookup = null;
function lookupRobberInBundle() {
  if (robberLookup) return;
  const src = [...(document.scripts || [])].map((x) => x.src).find((u) => /\/dist\/js\/shared\.[0-9a-f]+\.js/.test(u));
  if (!src) return;
  robberLookup = fetch(src)
    .then((r) => r.text())
    .then((t) => {
      const m = t.match(/assets\/icon_robber\.[0-9a-f]{20}\.svg/);
      if (m) pieceUrl.bundleRobber = src.replace(/js\/shared\.[^/]*$/, m[0]);
      const v = t.match(/assets\/card_vp\.[0-9a-f]{20}\.svg/);
      if (v) pieceUrl.bundleVp = src.replace(/js\/shared\.[^/]*$/, v[0]);
    })
    .catch(() => {});
}

function vpCardUrl() {
  const u = findAsset(/\/card_vp\./) || pieceUrl.bundleVp;
  if (!u) lookupRobberInBundle(); // picked up on the next refresh
  return u || null;
}

// kind: "robber" | "settlement" | "city". Falls back to any colour, then null.
function pieceIcon(kind) {
  const color = myColor();
  const key = `${kind}|${color}`;
  if (pieceUrl[key]) return pieceUrl[key];
  const u =
    kind === "robber"
      ? findAsset(/\/icon_robber\./) || pieceUrl.logRobber || pieceUrl.bundleRobber || findAsset(/\/icon_robber_[a-z]+\./)
      : (color && findAsset(new RegExp(`/${kind}_${color}\\.`))) || findAsset(new RegExp(`/${kind}_[a-z]+\\.`));
  if (u) pieceUrl[key] = u;
  else if (kind === "robber") lookupRobberInBundle(); // picked up on the next refresh
  return u || null;
}

const pieceImg = (kind, letter) => {
  const u = pieceIcon(kind);
  return u ? `<img draggable="false" src="${u}" alt="">` : `<b>${letter}</b>`;
};

// The rob box's advice (option B of the user's design canvas, 2026-10-16): one
// line per piece (both when one player is the best target for both): the odds,
// the card hoped for, "→", the piece on a light chip ("100% [wool] → (city)");
// when a bank trade covers the other missing card, a second line: the port
// badge with its rate under it, the cards given as "4× [brick]", "→", the card
// taken. No "steal:"/"potential" words, no four brick pictures, no robber
// footnote (it stands on the card). The card
// stays in the line: on a "?" card it is the only sign of what you hope for.
// Only its text is rewritten.
function markerTipHtml(name, kinds, adv) {
  const card = (t) =>
    faceUrl[t] ? `<img class="ci" draggable="false" src="${faceUrl[t]}" alt="">` : `<span class="ci" style="background:${PLACEHOLDER[t]}"></span>`;
  return kinds
    .map((k) => {
      const { res, p, trade } = adv.targets[k].picks[name];
      return (
        `<div class="ln odds"><b>${pct(p)}</b>${card(res)}<span class="arw">→</span><span class="chip">${pieceImg(k, k === "city" ? "C" : "S")}</span></div>` +
        (trade
          ? `<div class="ln trade">${portBadge(trade.rate, trade.give)}<span class="n">${trade.rate}×</span>${card(trade.give)}` +
            `<span class="arw">→</span>${card(trade.get)}</div>`
          : "")
      );
    })
    .join("");
}

// The port badge (the user's design, 2026-10-16): the resource's own picture
// (resPic: no card, no sail, in the tooltip's light colour) for its 2:1 port; a
// 3:1 port shows "?" as colonist's 3:1 sails do; a plain 4:1 bank trade shows
// the bank's icon; the rate under it, symbol and rate one unit in a fixed spot
// (the user's calls: the rate left for v19's option B, then came back). Every
// symbol gets the same area (BADGE_AREA) whatever its shape, so a wide one
// (brick, 1.78:1) isn't drawn bigger than a tall one (grain, 0.92:1): at one
// fixed height brick was 28 px wide. (A little port with sail and hull was
// tried and reverted.) Sizes: BADGE_AREA, BADGE_W, BADGE_SLOT (by ROB_CSS).
function portBadge(rate, give) {
  let pic = null;
  let aspect = 1; // width / height
  if (rate === 2) {
    pic = resPic(give);
    if (pic) aspect = resPicAspect[give] || 1;
    else if ((pic = faceUrl[give])) aspect = 1 / 1.394; // the card itself until the picture is built
  } else if (rate === 4) pic = findAsset(/\/bank\.[0-9a-f]+\.svg/); // square
  const size = `width:${Math.sqrt(BADGE_AREA * aspect).toFixed(1)}px;height:${Math.sqrt(BADGE_AREA / aspect).toFixed(1)}px`;
  // no bank icon loaded (not seen in a game: the bank shows it): just the rate, never "?" (that's 3:1)
  const sym = pic ? `<img draggable="false" src="${pic}" alt="" style="${size}">` : rate === 3 ? `<span class="q">?</span>` : "";
  return `<span class="port"><span class="sym">${sym}</span><i>${rate}:1</i></span>`;
}

// A resource's own picture, without the card, in one colour: colonist's card
// SVGs (card_<type>) are all built the same way (checked 2026-10-16): a shadow
// image, the card's gradient and three frame paths, then one group holding the
// drawing. Keep that group as one solid shape in PORT_INK, crop to it (measured
// in the page), serve it as a data: URL. PORT_INK is the tooltip's light text
// colour (the user's call on the dark tooltip, 2026-10-16; first the maroon of
// colonist's port sails, #5a2325, made for a white bubble).
const PORT_INK = "#f6f8fa";
const isLight = (c) => {
  const m = /^#([0-9a-f]{6})$/i.exec(c || "");
  if (!m) return false;
  const n = parseInt(m[1], 16);
  return 0.2126 * (n >> 16) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255) > 200;
};
const resPics = {}; // type -> data URL, or "pending" / "failed"
const resPicAspect = {}; // type -> the picture's width / height (for the port badge's equal area)
function resPic(t) {
  const v = resPics[t];
  if (v && v !== "pending" && v !== "failed") return v;
  if (!v && faceUrl[t]) {
    resPics[t] = "pending";
    buildResPic(t);
  }
  return null;
}

async function buildResPic(t) {
  try {
    const text = await (await fetch(faceUrl[t])).text();
    const svg = new DOMParser().parseFromString(text, "image/svg+xml").documentElement;
    const g = [...svg.children].find((c) => c.tagName === "g");
    if (!g) throw new Error("no drawing group");
    [...svg.children].forEach((c) => c !== g && c.remove());
    g.querySelectorAll("image").forEach((i) => !i.getAttribute("href") && !i.getAttribute("xlink:href") && i.remove()); // empty shadow images
    // One colour, like the sails: every painted shape in PORT_INK (faint shading layers dropped).
    for (const el of g.querySelectorAll("path, rect, circle, ellipse, polygon, polyline, line")) {
      if (Number(el.getAttribute("opacity") || 1) < 0.5) {
        el.remove();
        continue;
      }
      const f = el.getAttribute("fill");
      // brick: its light faces solid, its dark outlines left out, the gaps
      // between the bricks (one colour for all merges them into a block)
      if (f !== "none") el.setAttribute("fill", t === "brick" && !isLight(f) ? "none" : PORT_INK);
      if (el.getAttribute("stroke") && el.getAttribute("stroke") !== "none") el.setAttribute("stroke", PORT_INK);
      el.removeAttribute("style");
    }
    const holder = document.createElement("div");
    holder.style.cssText = "position:fixed;left:-10000px;top:0;visibility:hidden;";
    holder.appendChild(document.importNode(svg, true));
    document.documentElement.appendChild(holder);
    const bb = holder.firstChild.getBBox();
    holder.remove();
    if (!bb.width || !bb.height) throw new Error("empty drawing");
    svg.setAttribute("viewBox", `${bb.x - 2} ${bb.y - 2} ${bb.width + 4} ${bb.height + 4}`);
    svg.setAttribute("width", Math.round(bb.width + 4));
    svg.setAttribute("height", Math.round(bb.height + 4));
    resPicAspect[t] = (bb.width + 4) / (bb.height + 4);
    resPics[t] = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
    if (session) updateBoxes();
  } catch (e) {
    resPics[t] = "failed";
    ctLog(`${CT} ASSET | ${t} picture for the port badge: ${e && e.message}`);
  }
}

// The advice the rob boxes show (the demo overrides it).
function currentAdvice() {
  const s = session;
  return robDemo || (s && !s.catching ? s.tracker.robAdvice() : null);
}

// Where rob boxes stack: above your inventory strip, from its left edge (the
// strip's beige container, #player-card-inventory's parent; read-only probe
// probes/inventory-strip.js, 2026-10-16, the user to confirm). Colonist's
// tradeCreatorContainer around it, if present, counts too: it may grow upward
// while you put a trade or a discard together (not seen yet).
function robAnchor() {
  const inv = document.querySelector("#player-card-inventory");
  const box = inv && (inv.closest('[class*="tradeCreatorContainer"]') || inv.parentElement);
  const r = box && box.getBoundingClientRect();
  return r && r.width ? { left: r.left, top: r.top } : { left: 12, top: innerHeight - 12 };
}

function makeRobBox(n) {
  const host = document.createElement("div");
  host.setAttribute("data-ct-rob", n);
  host.style.cssText = `position:fixed;left:0;top:0;z-index:${Z};pointer-events:none;`;
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `<style>${ROB_CSS}</style><div class="rb" id="rb"><div class="box framed" id="box"></div><div class="say"></div></div>`;
  const wrap = shadow.getElementById("rb");
  const box = shadow.getElementById("box");
  wrap.style.setProperty("--frame", `${TRADE_FRAME}px`);
  raiseOnHover(host, wrap); // its tooltips can reach over a neighbouring box
  box.addEventListener("mouseover", (e) => logBoxTip(`${n} rob`, box, e));
  document.documentElement.appendChild(host);
  return { host, wrap, box, tip: wrap.querySelector(".say"), html: "", tipHtml: "", dx: 0, dy: 0 };
}

function updateRobBoxes() {
  const adv = currentAdvice();
  const want = new Map(); // name -> ["settlement", "city"]
  if (adv) {
    for (const kind of ["settlement", "city"]) {
      const t = adv.targets[kind];
      if (t) t.players.forEach((n) => (want.get(n) || want.set(n, []).get(n)).push(kind));
    }
  }
  const key = adv ? JSON.stringify(adv) : "";
  if (key !== robKey) {
    robKey = key;
    const pickText = (n, { res, p, trade }) =>
      `${n} ${res} ${pct(p)}${trade ? ` (after ${trade.rate}:1 ${trade.give} -> ${trade.get})` : ""}`;
    const what = adv
      ? `${adv.reason}${robDemo ? " (demo)" : ""}: ` +
        Object.entries(adv.targets)
          .map(([k, t]) => `${k} -> ${t.players.map((n) => pickText(n, t.picks[n])).join(", ")}`)
          .join(" | ") +
        " | rob box flies out"
      : "off";
    ctLog(`${CT} ROB | ${what}`);
  }
  for (const [n, rb] of robBoxes) {
    if (!want.has(n)) {
      robBoxes.delete(n);
      flyHome(n, rb);
    }
  }
  updateKnightGlow(adv);
  if (!want.size) return;
  const rows = new Map(panelRows().map((r) => [rowName(r), r]));
  const w = measureCardW();
  const anchor = robAnchor();
  let bottom = anchor.top - ROB_GAP; // the next rob box's frame ends here
  for (const [n, kinds] of want) {
    const row = rows.get(n);
    const av = row && row.querySelector('[class*="avatarAndPoints"] div[class*="avatar"]');
    let rb = robBoxes.get(n);
    if (!av) {
      if (rb) rb.host.style.display = "none";
      continue;
    }
    const fresh = !rb;
    if (fresh) robBoxes.set(n, (rb = makeRobBox(n)));
    rb.host.style.display = "";
    // The copy of their opp box, in their colour.
    const html = boxHtml(n, { steal: true }) + tagHtml(n, av);
    if (rb.html !== `${w}|${html}`) {
      rb.html = `${w}|${html}`;
      rb.box.style.setProperty("--w", `${w}px`);
      rb.box.innerHTML = html;
      const pc = playerColour(av);
      if (pc) {
        rb.box.style.setProperty("--pc", pc.bg);
        rb.box.style.setProperty("--pfg", pc.fg);
        rb.box.style.setProperty("--pts", pc.shadow);
      }
    }
    const tipHtml = markerTipHtml(n, kinds, adv);
    if (tipHtml !== rb.tipHtml) {
      rb.tipHtml = tipHtml;
      rb.tip.innerHTML = tipHtml;
      logTip(`${n} rob box advice`, rb.tip);
    }
    // Place it: its frame's bottom at `bottom`, from the strip's left edge.
    rb.dx = rb.box.offsetLeft;
    rb.dy = rb.box.offsetTop;
    const tag = rb.box.querySelector(".tag");
    // Its advice is centred on it: taller than the box (one player for both
    // pieces, with trades), it reaches below the frame; then that is the bottom.
    const below = Math.max(TRADE_FRAME, (rb.tip.offsetHeight - rb.box.offsetHeight) / 2);
    const boxTop = bottom - below - rb.box.offsetHeight; // where the box itself goes
    const left = anchor.left + rb.dx;
    if (fresh) {
      // Start on their opp box (or beside their row, invisible), then fly.
      const home = tradeHome(n, rb);
      rb.host.style.transition = "none";
      rb.host.style.opacity = home && home.shown ? "1" : "0";
      if (home) rb.host.style.transform = hostAt(rb, home.left, home.top);
      void rb.host.offsetWidth;
      rb.host.style.transition = `transform ${FLY_MS}ms cubic-bezier(.2, .8, .2, 1), opacity ${FLY_MS}ms ease-out`;
      rb.host.style.opacity = "1";
    }
    rb.host.style.transform = hostAt(rb, left, boxTop);
    // The next one goes above this one's tab (or its advice, if taller): as
    // close as the first version (the user's call).
    const hostTop = boxTop - rb.dy;
    bottom = Math.min(boxTop - TRADE_FRAME - (tag ? tag.offsetHeight : 0), hostTop + rb.tip.offsetTop) - ROB_GAP;
  }
}

function clearRobBoxes() {
  robBoxes.forEach((rb) => rb.host.remove());
  robBoxes.clear();
  robKey = "";
  updateKnightGlow(null);
}

// ------------------------------------------------------------ knight glow ---
// While the rob advice comes from a Knight you may play (not from a 7), your
// Knight cards in colonist's inventory strip get a soft golden glow (the user's
// call, 2026-10-16): our own frame over the cards, pulsing slowly (2.4 s each
// way, far from any flashing), letting every click through to colonist. Which
// of several Knights was bought this turn (not playable yet) the strip doesn't
// show, so the glow goes round all of them. Cards: after the strip's partition,
// enum 11 or the card_knight image (see readMyDev).
const KNIGHT_CSS = `
  :host { all: initial; }
  #g { box-sizing: border-box; width: var(--w); height: var(--h); border-radius: 8px; pointer-events: none;
       border: 3px solid #ffd23f; box-shadow: 0 0 12px 5px rgba(255, 196, 30, .85), inset 0 0 8px 2px rgba(255, 225, 120, .6);
       animation: ct-knight 2.4s ease-in-out infinite alternate; }
  @keyframes ct-knight { from { opacity: .55; } to { opacity: 1; } }
`;
let knightGlow = null; // { host, g, on }
let knightGlowDemo = false; // debug: glow even without the advice (a stand-in card if you hold no Knight)

function myKnightCards() {
  const inv = document.querySelector("#player-card-inventory");
  const part = inv && inv.querySelector('[class*="partition"]');
  const out = [];
  for (let el = part && part.nextElementSibling; el; el = el.nextElementSibling) {
    for (const card of el.querySelectorAll("[data-card-enum]")) {
      const src = (card.querySelector("img") || {}).src || "";
      if (card.getAttribute("data-card-enum") === "11" || /card_knight\./.test(src)) out.push(card);
    }
  }
  return out;
}

function updateKnightGlow(adv) {
  let cards = knightGlowDemo || (adv && adv.reason === "Knight") ? myKnightCards() : [];
  if (knightGlowDemo && !cards.length) cards = [...document.querySelectorAll("#player-card-inventory [data-card-enum]")].slice(-1);
  const rects = cards.map((c) => c.getBoundingClientRect()).filter((r) => r.width > 0);
  const on = rects.length > 0;
  if (!on) {
    if (knightGlow) knightGlow.host.style.display = "none";
  } else {
    if (!knightGlow) {
      const host = document.createElement("div");
      host.setAttribute("data-ct-knight-glow", "");
      host.style.cssText = `position:fixed;left:0;top:0;z-index:${Z};pointer-events:none;`;
      const shadow = host.attachShadow({ mode: "open" });
      shadow.innerHTML = `<style>${KNIGHT_CSS}</style><div id="g"></div>`;
      document.documentElement.appendChild(host);
      knightGlow = { host, g: shadow.getElementById("g"), on: false };
    }
    const l = Math.min(...rects.map((r) => r.left)) - 4;
    const t = Math.min(...rects.map((r) => r.top)) - 4;
    const r = Math.max(...rects.map((x) => x.right)) + 4;
    const b = Math.max(...rects.map((x) => x.bottom)) + 4;
    knightGlow.g.style.setProperty("--w", `${Math.round(r - l)}px`);
    knightGlow.g.style.setProperty("--h", `${Math.round(b - t)}px`);
    knightGlow.host.style.display = "";
    knightGlow.host.style.transform = `translate(${Math.round(l)}px, ${Math.round(t)}px)`;
  }
  if (knightGlow && on !== knightGlow.on) {
    knightGlow.on = on;
    ctLog(`${CT} ROB | knight glow ${on ? `on (${cards.length} card${cards.length === 1 ? "" : "s"}${knightGlowDemo ? ", demo" : ""})` : "off"}`);
  }
}

// Debug/verification hooks (no game input):
//   "ct-rob-demo" with detail "Name" or "Name|Other" toggles fake advice (see below)
//   "ct-force-rob-tip" hides/shows the rob boxes' advice
//   "ct-knight-glow-demo" toggles the knight glow (on the strip's last card if you hold no Knight)
document.addEventListener("ct-rob-demo", (e) => {
  // detail "Name" = a city rob box on Name (needs ore); "Name|Other" = also a
  // settlement rob box on Other: steal brick, after a 3:1 trade of ore for
  // wool. Add "|Knight" for advice from a playable Knight (the knight glow).
  const parts = String(e.detail).split("|");
  const [n, o] = parts.filter((x) => x !== "Knight");
  robDemo = robDemo
    ? null
    : {
        reason: parts.includes("Knight") ? "Knight" : "7",
        targets: {
          city: { players: [n], picks: { [n]: { res: "ore", p: 0.67, trade: null } }, spotUnknown: false },
          ...(o
            ? { settlement: { players: [o], picks: { [o]: { res: "brick", p: 1, trade: { rate: 3, give: "ore", get: "wool" } } }, spotUnknown: true } }
            : {}),
        },
      };
  render();
});
document.addEventListener("ct-dice-demo", () => {
  diceDemo = !diceDemo;
  render();
});
document.addEventListener("ct-force-rob-tip", () => {
  robBoxes.forEach((rb) => rb.tip.classList.toggle("shut"));
  updateBoxes();
});
document.addEventListener("ct-knight-glow-demo", () => {
  knightGlowDemo = !knightGlowDemo;
  render();
});

function render() {
  markRows();
  updateBoxes();
}

// ------------------------------------------------ game mode, layout, bank ---
// The bank ([class*="gameBankContainer"]; read-only probe probes/bank2.js,
// 2026-10-16, the user to confirm): one stack per card type ([data-card-enum]
// 1-5 resources, 10 dev cards, 6-8 the commodities of Cities & Knights), each
// with colonist's count badge. Every resource card is either in the bank or in
// a hand, so (cards of a type) - bank = what all hands hold together: ground
// truth for the tracker's totals (BANK lines). Some rooms hide the bank's counts;
// then colonist lets players ask for any card in a trade offer (its bundle:
// doesASinglePlayerHaveResourceCard returns true when hideBankCards is set).
const BANK_ENUM = { 1: "lumber", 2: "brick", 3: "wool", 4: "grain", 5: "ore", 10: "dev" };
function readBank() {
  const bank = document.querySelector('[class*="gameBankContainer"]');
  if (!bank) return null;
  const counts = {};
  let commodities = false;
  for (const card of bank.querySelectorAll("[data-card-enum]")) {
    const num = Number(card.getAttribute("data-card-enum"));
    if (num >= 6 && num <= 8) commodities = true;
    const badge = card.querySelector('[class*="countBadge"]');
    const n = badge ? parseInt(badge.textContent.trim(), 10) : NaN;
    if (BANK_ENUM[num] && Number.isFinite(n)) counts[BANK_ENUM[num]] = n;
  }
  return { shown: ORDER.some((t) => t in counts), counts, commodities };
}

const perType = () => (panelRows().length > 4 ? 24 : 19); // cards of each resource: 19, or 24 with 5-6 players

// What the tracker thinks all hands hold together, per type (each hand's sure
// cards plus its unknown ones weighted by their odds).
function trackedTotals() {
  const tot = Object.fromEntries(ORDER.map((t) => [t, 0]));
  for (const n of Object.keys(session.tracker.state.players)) {
    const v = session.tracker.handView(n);
    ORDER.forEach((t) => (tot[t] += v.sure[t] + v.unknown * v.could[t]));
  }
  return tot;
}

const resFmt = (o) => ORDER.map((t) => `${t[0].toUpperCase()}${o[t] === undefined ? "?" : +o[t].toFixed(1)}`).join(" ");

// BANK: at quiet moments, the bank against the tracker (OK or MISMATCH, which
// means the tracker lost or invented a card; it has to last 2 s, since the bank,
// the panel and the log update at slightly different moments).
function checkBank(s) {
  const b = readBank();
  if (!b || !s.tracker.state.me) return;
  if (!b.shown) {
    if (s.bankKey !== "hidden") {
      s.bankKey = "hidden";
      ctLog(`${CT} BANK | hidden: no counts shown (colonist then allows trade offers for any card)`);
    }
    return;
  }
  const per = perType();
  const tracked = trackedTotals();
  const held = Object.fromEntries(ORDER.map((t) => [t, b.counts[t] === undefined ? undefined : per - b.counts[t]]));
  const bad = ORDER.filter((t) => held[t] !== undefined && Math.abs(held[t] - tracked[t]) >= 0.5);
  if (bad.length) {
    if (!s.bankBad) s.bankBad = Date.now();
    if (Date.now() - s.bankBad < 2000) return;
  } else s.bankBad = 0;
  const line = `bank ${resFmt(b.counts)} dev ${b.counts.dev ?? "?"} | all hands ${resFmt(held)} | tracked ${resFmt(tracked)}`;
  const key = `${bad.join(",")}|${line}`;
  if (key !== s.bankKey) {
    s.bankKey = key;
    ctLog(`${CT} BANK | ${bad.length ? `MISMATCH ${bad.join(", ")}` : "OK"} | ${line}`);
  }
}

// MODE: players, bank shown or hidden, base game or Cities & Knights (the
// tracker only knows the base game), live game or colonist's replay page.
function logMode(s) {
  const b = readBank();
  const mode =
    `${panelRows().length} players | bank ${!b ? "not found" : b.shown ? "shown" : "hidden"} | ` +
    `${b && b.commodities ? "Cities & Knights (commodities in the bank): the tracker only knows the base game" : "base game"} | ` +
    `${location.pathname.startsWith("/replay") ? "replay page" : "live game"}`;
  if (mode !== s.modeKey) {
    s.modeKey = mode;
    ctLog(`${CT} MODE | ${mode}`);
  }
}

// LAYOUT: window size and zoom, and the feed's two parts (game log, chat) with
// their sizes and classes (hash cut off: "container.maximized.beige" is the
// chat open), whenever they change.
function logLayout(s) {
  const parts = [...s.feed.children].map((c) => {
    const r = c.getBoundingClientRect();
    const what = c.querySelector('[class*="chatContainer"]') ? "chat" : c.querySelector('[class*="virtualContainer"]') ? "log" : "other";
    const cls = [...(c.classList || [])].map((x) => x.replace(/-[\w]{6,}$/, "")).join(".");
    return `${what} ${Math.round(r.width)}x${Math.round(r.height)} (${cls})`;
  });
  const layout = `window ${innerWidth}x${innerHeight}, zoom ${devicePixelRatio} | ${parts.join(", ")}`;
  if (layout !== s.layoutKey) {
    s.layoutKey = layout;
    ctLog(`${CT} LAYOUT | ${layout}`);
  }
}

// Only the open/close buttons toggle a box (the user's call): clicks on the
// rows themselves are colonist's alone.
// Debug/verification hook (no game input): document.dispatchEvent(new CustomEvent("ct-toggle", {detail: "Name"}))
document.addEventListener("ct-toggle", (e) => session && toggleBox(String(e.detail)));
window.addEventListener("resize", () => updateBoxes());
setInterval(() => {
  syncMyDev();
  syncTurn(session);
  // The strip can settle after the quiet check has run, so look again while quiet.
  if (session && !session.catching && Date.now() - session.lastScan >= 1500) {
    checkMyHand(session);
    checkBank(session);
  }
  if (session) {
    logMode(session);
    logLayout(session);
  }
  updateBoxes(); // layout can shift (panel scroll, resize)
  updateBugButton();
}, 500);

// Ground truth for our own hand: colonist shows it exactly, but the inventory
// strip is only settled when its card total equals the panel's count for us.
// While you put a trade offer together the offered cards leave the strip, and
// cards you receive (trade, steal) land in it a moment after the log row.
function checkMyHand(s) {
  const actual = readMyHand();
  const me = s.tracker.state.me;
  if (!actual || !me || !s.tracker.state.players[me]) return;
  const row = readPanel().find((p) => p.name === me);
  const shown = row ? Number(row.hand) : NaN;
  if (Object.values(actual).reduce((a, b) => a + b, 0) !== shown) return; // strip mid-change
  const tracked = s.tracker.state.players[me].res;
  const ok = Object.keys(actual).every((k) => actual[k] === tracked[k]);
  const key = JSON.stringify(actual) + JSON.stringify(tracked);
  if (key !== s.handKey) {
    s.handKey = key;
    ctLog(`${CT} MYHAND | ${ok ? "OK" : "MISMATCH"} actual=${JSON.stringify(actual)} tracked=${JSON.stringify(tracked)}`);
  }
}

// Once things have been quiet for a moment (the panel and the log rows update at
// slightly different times) colonist's real hand sizes are ground truth, so we
// (1) drop every possible-world whose hand sizes disagree with the panel and
// (2) report players whose hand size we still cannot explain. Console only.
function scheduleQuietCheck() {
  clearTimeout(session.driftTimer);
  session.driftTimer = setTimeout(() => {
    const s = session;
    if (!s || s.catching) return;
    const hands = {};
    readPanel().forEach((row) => {
      const n = Number(row.hand);
      if (row.name && row.hand !== undefined && Number.isFinite(n)) hands[row.name] = n;
    });
    const info = s.tracker.worldsInfo();
    if ((info.degraded || info.overflow) && !s.engineWarned) {
      s.engineWarned = true;
      ctLog(`${CT} ENGINE | worlds engine off (${info.degraded ? "inconsistent: " + info.why : "too many worlds"}); using the simple model`);
    }
    checkMyHand(s);
    const before = info.count;
    const matched = s.tracker.observeHands(hands);
    const after = s.tracker.worldsInfo().count;
    if (matched && after !== before) {
      ctLog(`${CT} OBSERVE | worlds ${before} -> ${after}`);
      render();
    }
    const now = new Set();
    Object.entries(hands).forEach(([name, n]) => {
      if (s.tracker.totalBest(name) !== n) now.add(name);
    });
    if (!matched) now.add("(no world matches the panel)");
    const key = [...now].sort().join(",");
    if (key !== s.driftKey) {
      s.driftKey = key;
      if (now.size) ctLog(`${CT} DRIFT | ${key}`);
    }
  }, 1500);
}

// ---------------------------------------------------------------- bug marks ---
// For testers: a red button with a white bug, the size of colonist's round help
// buttons on the left (settings, rules, full screen, info) and in the next free
// slot under them ([class*="gameHelpButtonsContainer"]; read-only probe
// probes/left-icons.js, 2026-10-16, the user to confirm); bottom left of the
// window when that column isn't there (lobby). A click writes a block into the
// tracker log, "BUG MARK n", with a snapshot of everything the tracker shows
// and believes at that moment, then offers a one-line note ("what looked
// wrong?", optional; Enter saves it, Esc skips). Searching the downloaded log
// for BUG MARK finds each one; the log rows just above it are what led there.
// The note's input is a plain element in the page (not in our shadow root), so
// colonist sees an input with focus and its keyboard shortcuts stay quiet; its
// key events also stop at the input.
const BUG_KEY = "ct-bug-marks"; // marks so far in this tab (numbers keep counting across reloads)
const BUG_RED = "#d23b3b";
const BUG_SVG =
  `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11.3" fill="${BUG_RED}" stroke="rgba(0,0,0,.45)" stroke-width="0.7"/>` +
  `<g stroke="#fff" stroke-width="1.3" stroke-linecap="round" fill="none">` +
  `<path d="M8.6 11.2 6.2 9.9M8.3 13.9H5.7M8.7 16.5 6.4 17.9M15.4 11.2 17.8 9.9M15.7 13.9H18.3M15.3 16.5 17.6 17.9M10.9 6.6 9.8 5M13.1 6.6 14.2 5"/></g>` +
  `<circle cx="12" cy="8.2" r="2.1" fill="#fff"/><ellipse cx="12" cy="13.8" rx="3.6" ry="4.6" fill="#fff"/>` +
  `<path d="M12 10.4V18.2" stroke="${BUG_RED}" stroke-width="0.9"/></svg>`;
const BUG_CSS = TIP_CSS + `
  :host { all: initial; }
  #b { position: relative; display: block; width: var(--d); height: var(--d); border-radius: 50%; cursor: pointer;
       pointer-events: auto; filter: drop-shadow(0 1px 2px rgba(0,0,0,.35)); }
  #b:hover { filter: drop-shadow(0 1px 2px rgba(0,0,0,.35)) brightness(1.15); }
  #b svg { display: block; width: 100%; height: 100%; }
  #b .tip { left: calc(100% + 8px); bottom: auto; top: 50%; transform: translateY(-50%); white-space: nowrap; }
  #b:hover .tip { display: block; }
  #b.done svg circle:first-child { fill: #3a9c4a; }
`;
let bug = null; // { host, btn, d, note }

function bugCount() {
  try {
    return Number(sessionStorage.getItem(BUG_KEY)) || 0;
  } catch (e) {
    return bug ? bug.count || 0 : 0;
  }
}

function updateBugButton() {
  if (!bug) {
    const host = document.createElement("div");
    host.setAttribute("data-ct-bug", "");
    host.style.cssText = `position:fixed;left:0;top:0;z-index:${Z};pointer-events:none;`;
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML =
      `<style>${BUG_CSS}</style><div id="b" role="button" aria-label="Mark a bug in the tracker log">${BUG_SVG}` +
      `<div class="tip"><div class="tt">Mark a bug</div><div class="tf">Flags this moment in the tracker log</div></div></div>`;
    document.documentElement.appendChild(host);
    const btn = shadow.getElementById("b");
    btn.addEventListener("click", () => bugMark());
    bug = { host, btn, d: 0, count: 0 };
  }
  // The next slot under colonist's help buttons, as large as their circles.
  const col = document.querySelector('[class*="gameHelpButtonsContainer"]');
  const icons = col
    ? [...col.querySelectorAll("img")]
        .map((i) => i.getBoundingClientRect())
        .filter((r) => r.width > 0 && r.height > 0)
        .sort((a, b) => a.top - b.top)
    : [];
  let d, left, top;
  if (icons.length) {
    const last = icons[icons.length - 1];
    const pitch = icons.length > 1 ? icons[1].top - icons[0].top : last.height + 14;
    d = Math.round(last.height * 0.84); // colonist's circles fill ~84% of their 43 px images
    left = last.left + last.width / 2 - d / 2;
    top = last.top + pitch + (last.height - d) / 2;
  } else {
    d = 36;
    left = 12;
    top = innerHeight - d - 12;
  }
  if (d !== bug.d) {
    bug.d = d;
    bug.btn.style.setProperty("--d", `${d}px`);
  }
  bug.host.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
}

// The snapshot under a bug mark: one line per item, each prefixed "MARK | n |".
function bugSnapshot(L) {
  L(`page ${location.href} | window ${innerWidth}x${innerHeight}, zoom ${devicePixelRatio}`);
  const s = session;
  if (!s) return L("no game open");
  const tr = s.tracker;
  const st = tr.state;
  const line = (label, f) => {
    try {
      L(`${label} ${f()}`);
    } catch (e) {
      L(`${label} (failed: ${e && e.message})`);
    }
  };
  line("game:", () => `me ${st.me} | last log row ${s.maxIdx} | turn ${s.turnName || "?"} | rolled last ${st.lastRoller || "?"} | catching up ${s.catching}`);
  line("mode:", () => s.modeKey || "?");
  line("layout:", () => s.layoutKey || "?");
  line("panel:", () => JSON.stringify(readPanel()));
  line("bank:", () => {
    const b = readBank();
    return !b ? "not found" : !b.shown ? "hidden" : `${resFmt(b.counts)} dev ${b.counts.dev ?? "?"} | tracked in all hands ${resFmt(trackedTotals())}`;
  });
  line("your hand:", () => `actual ${JSON.stringify(readMyHand())} | tracked ${JSON.stringify((st.players[st.me] || {}).res || null)} | your dev cards ${JSON.stringify(readMyDev())}`);
  const est = tr.devEstimate();
  for (const row of panelRows()) {
    const n = rowName(row);
    if (!n || n === st.me) continue;
    line(`${n}:`, () => {
      const v = tr.handView(n);
      const could = ORDER.filter((t) => v.could[t] >= 0.005).map((t) => `${t} ${pct(v.could[t])}`).join(" ");
      const box = ORDER.filter((t) => v.sure[t]).map((t) => `${t} ${v.sure[t]}`).concat(v.unknown ? [`? ${v.unknown}${could ? ` (each: ${could})` : ""}`] : []).join(", ") || "no cards";
      const odds = tr.stealOdds(n);
      const steal = odds ? ORDER.filter((t) => odds[t] > 0).map((t) => `${t} ${pct(odds[t])}`).join(" ") : "-";
      const combos = (v.unknown > 0 && tr.unknownCombos(n) || []).slice(0, 4).map((c) => `${ORDER.filter((t) => c.cards[t]).map((t) => `${c.cards[t]} ${t}`).join("+")} ${pct(c.p)}`).join(", ");
      return `box ${boxes.has(n) ? "open" : "closed"}: ${box} | hand ${tr.totalBest(n)} | steal ${steal}${combos ? ` | ? together: ${combos}` : ""} | source ${v.source}`;
    });
    line(`${n} dev:`, () => {
      const cards = est.cards[n] || [];
      const vp = tr.vpSuspects(n);
      return `${cards.map((c) => `#${c.id} ${devFmt(c.dist)} held ${c.held}`).join(", ") || "none"} | suspected VP ${vp ? vp.cards.map((c) => pct(c.p)).join(" ") + (vp.sure ? `, ${vp.sure} at 90%+` : "") : "none"}`;
    });
    line(`${n} ports:`, () => JSON.stringify(tr.ports(n)));
  }
  line("deck:", () => (est.deck.size > 0 ? `${est.deck.size} left | ${devFmt(est.deck.chance)}` : "empty"));
  line("rob advice:", () => JSON.stringify(currentAdvice()));
  line("trade offers open:", () => [...openOffers().keys()].join(", ") || "none");
  line("worlds engine:", () => JSON.stringify(tr.worldsInfo()));
  line("warnings so far:", () => `${st.warnings.length}${st.warnings.length ? ", last: " + st.warnings.slice(-3).join(" / ") : ""}`);
}

function bugMark() {
  const n = bugCount() + 1;
  try {
    sessionStorage.setItem(BUG_KEY, String(n));
  } catch (e) {}
  if (bug) bug.count = n;
  const time = new Date().toLocaleTimeString("en-US");
  const L = (t) => ctLog(`${CT} MARK | ${n} | ${t}`);
  L(`==================== BUG MARK ${n} (${time}) ====================`);
  try {
    bugSnapshot(L);
  } catch (e) {
    L(`snapshot failed: ${e && e.message}`);
  }
  L(`==================== end of BUG MARK ${n} ====================`);
  flushLog();
  bugNote(n);
}

// The note: a small box right of the button, in the page (see above).
function bugNote(n) {
  if (bug.note) bug.note.remove();
  const r = bug.btn.getBoundingClientRect();
  const box = document.createElement("div");
  box.setAttribute("data-ct-bug-note", "");
  box.style.cssText =
    `all:initial;position:fixed;z-index:${Z + 1};left:${Math.round(r.right + 10)}px;top:${Math.round(r.top)}px;` +
    "display:block;width:350px;box-sizing:border-box;padding:8px 10px;border-radius:8px;background:#404040;color:#fff;" +
    'font:13px "Open Sans",sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.4);';
  const title = document.createElement("div");
  title.style.cssText = "all:initial;display:block;font:600 13px 'Open Sans',sans-serif;color:#fff;margin-bottom:6px;";
  title.textContent = `BUG MARK ${n} saved. What looked wrong? (optional)`;
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "e.g. the ? card can't be wool";
  input.style.cssText =
    "all:initial;display:block;width:100%;box-sizing:border-box;padding:5px 7px;border-radius:5px;background:#fff;color:#222;" +
    'font:13px "Open Sans",sans-serif;';
  const hint = document.createElement("div");
  hint.style.cssText = "all:initial;display:block;margin-top:5px;font:11px 'Open Sans',sans-serif;color:#cfcfcf;";
  hint.textContent = "Enter saves the note, Esc skips it";
  box.append(title, input, hint);
  document.documentElement.appendChild(box);
  box.style.top = `${Math.round(Math.max(8, r.top + r.height / 2 - box.offsetHeight / 2))}px`; // centred on the button
  bug.note = box;
  const close = () => {
    box.remove();
    if (bug.note === box) bug.note = null;
    bug.btn.classList.add("done"); // green for a moment: saved
    setTimeout(() => bug.btn.classList.remove("done"), 1500);
  };
  const stop = (e) => e.stopPropagation();
  ["keyup", "keypress"].forEach((t) => input.addEventListener(t, stop));
  input.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter") {
      const text = input.value.trim();
      if (text) {
        ctLog(`${CT} MARK | ${n} | note for BUG MARK ${n}: ${text}`);
        flushLog();
      }
      close();
    } else if (e.key === "Escape") close();
  });
  setTimeout(() => input.focus(), 0);
}

// Debug (no game input): "ct-bug-mark" writes a mark as the button does.
document.addEventListener("ct-bug-mark", () => bugMark());

// ------------------------------------------------------------------- scan ---
function handleRow(s, idx, line, replay = false) {
  if (s.maxIdx >= 0 && idx > s.maxIdx + 1) {
    ctLog(`${CT} GAP | missed ${s.maxIdx + 1}..${idx - 1}`);
  }
  if (idx > s.maxIdx) s.maxIdx = idx;
  ctLog(`${CT} LOG | ${idx} | ${line}`);
  if (!s.ckWarned && /<(Cloth|Paper|Coin)>/.test(line)) {
    s.ckWarned = true;
    ctLog(`${CT} WARN | ${idx} | Cities & Knights commodities in the log: the tracker only knows the base game, its numbers are wrong here`);
  }
  try {
    const live = !s.catching && !replay;
    const before = live ? s.tracker.devEstimate().deck : null;
    const r = s.tracker.processLine(line);
    if (before && r && r.type === "bought") logDevBuy(s, r.player, before);
    if (live && r && r.type === "offer") checkOffer(s, idx, r);
  } catch (e) {
    ctLog(`${CT} ERROR | ${idx} | ${e && e.message}`);
  }
  // The tracker's own warnings, with the row that caused them.
  const w = s.tracker.state.warnings;
  for (s.warnSeen = s.warnSeen || 0; s.warnSeen < w.length; s.warnSeen++) ctLog(`${CT} WARN | ${idx} | ${w[s.warnSeen]}`);
}

// An opponent asked for cards: colonist only allows that while at least one of
// each wanted type is in some hand (see tracker-core's offer handler), unless
// the room hides the bank: then any offer is allowed. A tester saw an offer for
// wool while the tracker showed none anywhere and held none themselves; their
// logs (2026-10-16) had 13 such offers with complete log accounting, so their
// rooms most likely hid the bank. tracker-core can only check its own beliefs;
// here your real hand (the inventory, when settled) replaces the tracked one,
// and the bank tells which case it is.
function checkOffer(s, idx, r) {
  const me = s.tracker.state.me;
  if (r.player === me) return;
  const actual = readMyHand();
  const mine = readPanel().find((p) => p.name === me);
  const settled = actual && mine && Object.values(actual).reduce((a, b) => a + b, 0) === Number(mine.hand);
  const tracked = (s.tracker.state.players[me] || {}).res || {};
  for (const t of new Set(r.want || [])) {
    const others = Object.keys(s.tracker.state.players)
      .filter((n) => n !== me)
      .map((n) => {
        const v = s.tracker.inspect(n);
        return [n, v.res[t] + v.plus[t]]; // the most they could hold
      });
    const own = settled ? actual[t] : tracked[t] || 0;
    if (own > 0 || others.some(([, max]) => max > 0)) continue;
    const bank = readBank();
    if (bank && !bank.shown) {
      ctLog(`${CT} OFFER | ${idx} | ${r.player} asked for ${t}, which no hand holds by the log: allowed, the game hides the bank`);
      continue;
    }
    ctLog(
      `${CT} WARN | ${idx} | ${r.player} asked for ${t}, but no opponent can hold one by our tracking and you hold ${own}: ` +
        `the tracker lost a ${t} (the bank shows ${bank && bank.counts[t] !== undefined ? `${bank.counts[t]} of ${perType()}` : "nothing"}) | ` +
        `your hand ${settled ? "actual" : "(strip not settled)"} ${JSON.stringify(settled ? actual : null)} tracked ${JSON.stringify(tracked)}`
    );
  }
}

// DEV line at each live buy: the deck's odds just before, the bought card's odds
// just after (always equal while the counts add up), and the counts. For a
// tester's report: deck at 83% VP / 17% YoP, then the bought card at 100%.
function logDevBuy(s, name, before) {
  const est = s.tracker.devEstimate();
  const fmt = (dist) =>
    Object.entries(dist)
      .filter(([, p]) => p >= 0.005)
      .map(([t, p]) => `${t} ${Math.round(p * 100)}%`)
      .join(", ");
  const cards = est.cards[name];
  const card = cards && cards[cards.length - 1];
  const d = est.deck;
  const adds = !est.ownKnown || d.unaccounted === d.size + d.held ? "" : ` | COUNTS OFF: ${d.unaccounted} unaccounted vs ${d.size} in the deck + ${d.held} held`;
  ctLog(
    `${CT} DEV | ${name} bought (${d.size} left): deck before ${fmt(before.chance)} | their new card ${card ? fmt(card.dist) : "(yours: known)"}${adds}`
  );
}

// The log is a virtualized list: only the rows in view exist in the page. After a
// reload (or when joining mid-game) colonist shows just one window, so we scroll
// the log through its whole history once, collect every row, then process them
// in order and put the scroll position back.
// Colonist only draws log rows while its tab is visible (a minimized or covered
// window reads as hidden), so the catch-up scroll waits for that.
function whenVisible() {
  if (document.visibilityState !== "hidden") return Promise.resolve();
  ctLog(`${CT} CATCHUP | waiting for the tab to be visible`);
  return new Promise((resolve) => {
    const on = () => {
      if (document.visibilityState === "hidden") return;
      document.removeEventListener("visibilitychange", on);
      resolve();
    };
    document.addEventListener("visibilitychange", on);
  });
}

async function catchUp(s) {
  const scroller = logScroller(s.feed);
  if (!scroller || scroller.scrollHeight <= scroller.clientHeight * 1.5) return; // short log: nothing to do
  s.catching = true;
  const wasAtBottom = scroller.scrollTop >= scroller.scrollHeight - scroller.clientHeight - 5;
  const saved = scroller.scrollTop;
  const step = Math.max(60, scroller.clientHeight * 0.8);
  ctLog(`${CT} CATCHUP | start height=${scroller.scrollHeight} view=${scroller.clientHeight}`);
  // Which rows colonist has drawn right now ("first-last" row index).
  const drawn = () => {
    const idx = logRows(s.feed).map((el) => Number(el.getAttribute("data-index")));
    return idx.length ? `${Math.min(...idx)}-${Math.max(...idx)}` : "";
  };
  const t0 = Date.now();
  let steps = 0;
  let timeouts = 0;
  for (let top = 0; session === s; top += step) {
    await whenVisible();
    const before = drawn();
    scroller.scrollTop = top;
    // Let colonist draw this window: wait until the drawn rows change (at most
    // 1 s; a fixed 50 ms missed rows right after the tab became visible).
    let moved = false;
    for (let waited = 0; waited < 1000 && !moved; waited += 50) {
      await new Promise((r) => setTimeout(r, 50));
      moved = drawn() !== before;
    }
    steps++;
    if (!moved) timeouts++;
    scan();
    if (top >= scroller.scrollHeight) break;
  }
  s.catching = false;
  if (session !== s) return;
  const rows = [...s.pending.entries()].sort((a, b) => a[0] - b[0]);
  s.pending.clear();
  rows.forEach(([idx, line]) => handleRow(s, idx, line, true));
  scroller.scrollTop = wasAtBottom ? scroller.scrollHeight : saved;
  ctLog(`${CT} CATCHUP | done rows=${rows.length} maxIdx=${s.maxIdx} steps=${steps} timeouts=${timeouts} ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  scan();
}

function scan() {
  const s = session;
  if (!s) return;
  s.lastScan = Date.now();
  if (!s.tracker.state.me) {
    const me = findMe();
    if (me) {
      s.tracker.setMe(me);
      ctLog(`${CT} me = ${me}`);
    }
  }

  const rows = logRows(s.feed)
    .map((el) => ({ el, idx: Number(el.getAttribute("data-index")) }))
    .sort((a, b) => a.idx - b.idx);

  for (const { el, idx } of rows) {
    if (s.seenIdx.has(idx)) continue;
    const line = flatten(el);
    if (!line) continue; // empty row (or not rendered yet)
    s.seenIdx.add(idx);
    // While catching up we only collect; rows are processed in order afterwards.
    if (s.catching) s.pending.set(idx, line);
    else handleRow(s, idx, line);
  }

  const panel = JSON.stringify(readPanel());
  if (panel !== s.lastPanel) {
    s.lastPanel = panel;
    ctLog(`${CT} PANEL | ${panel}`);
  }
  syncMyDev();
  syncTurn(s); // after syncMyDev: a turn that starts snapshots the dev cards just read
  render();
  scheduleQuietCheck();
}

// ----------------------------------------------------------------- attach ---
function attach(feed, panelEl) {
  if (session) {
    session.observer.disconnect();
    clearTimeout(session.driftTimer);
  }
  closeAllBoxes();
  clearRobBoxes();
  injectPageStyle();
  const observer = new MutationObserver(scan); // no debounce: rows are virtualized
  session = {
    feed,
    panelEl,
    observer,
    tracker: TrackerCore.createTracker({ me: findMe() }),
    seenIdx: new Set(),
    maxIdx: -1,
    lastPanel: "",
    driftKey: "",
    driftTimer: null,
    myDevKey: "unset",
    myDevBad: 0,
    handKey: "",
    lastScan: 0, // when the log or panel last changed (ms)
    turnName: null, // whose turn the page shows
    catching: false,
    pending: new Map(), // idx -> line, collected while catching up
  };
  const opts = { childList: true, subtree: true, characterData: true };
  observer.observe(feed, opts);
  observer.observe(panelEl, opts);
  // Trade offer windows come and go here: redraw at once (their box copies).
  const tradeEl = document.querySelector('div[class*="gameTradeOffersContainer"]');
  if (tradeEl) observer.observe(tradeEl, { childList: true, subtree: true });
  ctLog(`${CT} watching log + panel (me=${session.tracker.state.me})`);
  // catchUp() switches to collect-only mode synchronously (before its first
  // await), so the first scan below cannot process rows out of order.
  const s = session;
  catchUp(s).then(() => session === s && render()); // opens the boxes (not during the catch-up)
  scan();
}

// Colonist is a single-page app: the log element is replaced between games, so
// keep checking and re-attach (with fresh state) whenever it changes.
function watchForGame() {
  const feed = document.querySelector('div[class*="gameFeedsContainer"]');
  const panelEl = document.querySelector('[data-player-information-container="true"]');
  if (feed && panelEl) {
    if (!session || session.feed !== feed || session.panelEl !== panelEl) attach(feed, panelEl);
  } else if (session) {
    session.observer.disconnect();
    session = null;
    closeAllBoxes();
    clearRobBoxes();
    hideDeckTip();
    ctLog(`${CT} game closed`);
  }
}

watchForGame();
setInterval(watchForGame, 1000);
