// The tester log: every [CT] line the tracker wrote while colonist.io was open,
// kept in chrome.storage.local by content.js ("ctlog:<page load>:<chunk>").
// "Download log" saves it as one .txt in the recorder's format, ready for
// review-log.mjs, under a header that explains how to read it (lines starting
// "#": review-log skips them); "Clear log" deletes it (a second click confirms).
const store = chrome.storage.local;
const $ = (id) => document.getElementById(id);

async function readLog() {
  const all = await store.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith("ctlog:")).sort(); // oldest page load first
  return { all, keys };
}

// The header of the downloaded file. No "[CT]" in it: review-log reads lines
// with that tag.
const HEADER = `#
# HOW TO READ THIS LOG
# - Search for BUG MARK to jump to each moment someone pressed the red bug
#   button during a game (left side of the game, under colonist's round
#   buttons). Each mark is a block of what the tracker showed and believed
#   right then, then the note typed in, if any. The rows just above a mark
#   are what led up to it.
# - Each line: the time, "[extension] log:", a tag, then details split by " | ".
#   A "loaded" line starts each page load; "watching log + panel" starts each
#   game (or the re-read after a reload).
#
# TAGS
#   loaded, ENV      page load: extension version, browser, screen, window, zoom, address
#   MODE             players, the bank shown or hidden, base game or Cities & Knights
#   LAYOUT           window size, the game log's and the chat's sizes (chat open or closed)
#   CATCHUP          after a reload the tracker re-reads the whole game log
#   LOG | n | text   game log row n as read (icons as <Wool>, <Development Card>...)
#   GAP              row numbers never seen (single rows: colonist's empty spacer rows, harmless)
#   PANEL            each player's card counts as colonist shows them
#   TURN             whose turn it is
#   BOX              an open box's cards; "? 2 (each: wool 50% ...)" = 2 cards of unknown type
#   DEVS, DECK       each opponent's face-down dev cards with their odds; the next card from the deck
#   DEV              a dev card bought: the deck's odds just before, the new card's just after
#   VP               suspected Victory Point cards (face up in the box; the ribbon's (+n) at 90%)
#   ROB              rob advice on or off: whom to rob, for which card and piece
#   TRADE, OFFER     an opponent's trade offer open or closed; an offer for a card no hand holds
#   TIP              a tooltip of ours that was hovered, and what it said
#   BANK             the bank's counts against what the tracker thinks all hands hold (OK / MISMATCH)
#   MYHAND, MYDEV    your own cards: colonist's against the tracker's (OK / MISMATCH)
#   DRIFT            a hand size the tracker can't explain at a quiet moment
#   OBSERVE, ENGINE  the tracker's possible-worlds engine narrowing down, or switched off
#   DICE             the boxes sliding aside for your dice roll
#   WARN, ERROR      something the tracker found odd; a bug in the extension
#   MARK             a bug mark block (see BUG MARK above)
# ------------------------------------------------------------------------------`;

const marksIn = (all, keys) => keys.reduce((n, k) => n + (all[k].match(/ MARK \| \d+ \| =+ BUG MARK /g) || []).length, 0);

async function refresh() {
  const { all, keys } = await readLog();
  const loads = new Set(keys.map((k) => k.split(":")[1])).size;
  const kb = Math.round(keys.reduce((s, k) => s + all[k].length, 0) / 1024);
  const marks = marksIn(all, keys);
  $("info").textContent = keys.length
    ? `${loads} page load${loads === 1 ? "" : "s"} of colonist.io logged (${kb} KB), ${marks} bug mark${marks === 1 ? "" : "s"}. ` +
      "Download the log and send the file in."
    : "Nothing logged yet: play a game on colonist.io first.";
  $("download").disabled = $("clear").disabled = !keys.length;
}

$("download").addEventListener("click", async () => {
  const { all, keys } = await readLog();
  const head = `--- Colonist Tracker log, exported ${new Date().toISOString()}, extension ${chrome.runtime.getManifest().version}`;
  const text = [head, HEADER, ...keys.map((k) => all[k])].join("\n") + "\n";
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `colonist-tracker-log-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.txt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
});

let armed = false;
$("clear").addEventListener("click", async () => {
  if (!armed) {
    armed = true;
    $("clear").textContent = "Click again to delete the log";
    return;
  }
  const { keys } = await readLog();
  await store.remove(keys);
  armed = false;
  $("clear").textContent = "Clear log";
  refresh();
});

refresh();
