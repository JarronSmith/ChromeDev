// Colonist Tracker - core logic (no DOM access).
// Input: normalized one-line log messages from content.js, e.g.
//   "Pliner gave <Brick> and got <Lumber> from Bailar"
// (icons are written as <alt text>, see flatten() in content.js).
// Works as a content script (global TrackerCore) and in Node (module.exports).

(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.TrackerCore = factory();
})(typeof self !== "undefined" ? self : this, function () {
  const RES = ["lumber", "brick", "wool", "grain", "ore"];

  // Costs (note: a settlement does NOT cost ore).
  const COSTS = {
    road: { lumber: 1, brick: 1 },
    settlement: { lumber: 1, brick: 1, wool: 1, grain: 1 },
    city: { grain: 2, ore: 3 },
    devcard: { wool: 1, grain: 1, ore: 1 },
  };

  // Pieces per player. A city replaces one of your settlements, which goes back
  // to your pool, so a player can have at most 9 buildings on the board.
  const PIECES = { settlement: 5, city: 4 };

  // Rob advice marks an opponent only at or above this chance of stealing the
  // card: 1 in 3 (the user's call; it was 50%).
  const ROB_MIN = 1 / 3;
  // Suspected Victory Point cards (the user's rules, 2026-10-15), on whole
  // percentages as the tooltips show them: the "50% condition" = VP at least
  // VP_SHOW and no other type above VP_OTHER_MAX (50% VP + 25% Monopoly: yes;
  // 26% Monopoly: no); "high confidence" = VP at least VP_SURE (counted into
  // the "(n)" on the VP ribbon; may be tuned).
  const VP_SHOW = 0.5;
  const VP_OTHER_MAX = 0.25;
  const VP_SURE = 0.9;

  // Development cards: the deck has 25 cards. Names match the log's icon alt text
  // ("Victory Point" is never logged: those only reveal when a player wins).
  const DEV_TYPES = ["Knight", "Victory Point", "Road Building", "Year of Plenty", "Monopoly"];
  const DEV_TOTAL = { Knight: 14, "Victory Point": 5, "Road Building": 2, "Year of Plenty": 2, Monopoly: 2 };
  const DEV_CARDS = 25;
  // Chance that a holder plays a given card on any one turn where they could
  // (turn after the purchase, no other dev card played that turn). From your
  // rules of thumb and the recorded games: Knights and Road Building go quickly,
  // Year of Plenty fastest, Monopoly is held, Victory Point is never played.
  const DEV_HAZARD = { Knight: 0.45, "Victory Point": 0, "Road Building": 0.4, "Year of Plenty": 0.5, Monopoly: 0.15 };

  // Probability that each held card is each type.
  //   pool[k]  = how many cards of type k are still unaccounted for (in the deck
  //              or in an opponent's hand) = total - played - my own known cards
  //   sList[i] = how many chances card i has already had to be played and wasn't
  // Model: the held cards were drawn at random from the pool (weight = falling
  // factorials of the pool counts), and a card of type k that survives s chances
  // has likelihood (1 - hazard[k])^s. Cards with the same s are interchangeable,
  // so we group them and do one small DP over type-count vectors per group.
  function estimateDev(pool, sList, hazard = DEV_HAZARD) {
    const K = DEV_TYPES.length;
    const like = (k, s) => Math.pow(1 - hazard[DEV_TYPES[k]], s);
    const poolSum = pool.reduce((a, b) => a + b, 0);
    const fallback = () => pool.map((n) => (poolSum ? n / poolSum : 1 / K));

    function dp(list) {
      let states = new Map([["0,0,0,0,0", { c: [0, 0, 0, 0, 0], w: 1 }]]);
      for (const s of list) {
        const next = new Map();
        for (const st of states.values()) {
          for (let k = 0; k < K; k++) {
            const left = pool[k] - st.c[k];
            if (left <= 0) continue; // pool has no more of this type
            const w = st.w * left * like(k, s);
            if (w === 0) continue;
            const c = st.c.slice();
            c[k]++;
            const key = c.join();
            const e = next.get(key);
            if (e) e.w += w;
            else next.set(key, { c, w });
          }
        }
        states = next;
      }
      return states;
    }

    const bySurvived = new Map(); // s -> marginal vector
    for (const s0 of new Set(sList)) {
      const others = sList.slice();
      others.splice(others.indexOf(s0), 1); // leave one card of this group out
      const states = dp(others);
      const m = new Array(K).fill(0);
      for (const st of states.values()) {
        for (let k = 0; k < K; k++) {
          const left = pool[k] - st.c[k];
          if (left > 0) m[k] += st.w * left * like(k, s0);
        }
      }
      const z = m.reduce((a, b) => a + b, 0);
      bySurvived.set(s0, z > 0 ? m.map((v) => v / z) : fallback());
    }
    return { marg: sList.map((s) => bySurvived.get(s)) };
  }

  const ICONS = "((?: <[^>]+>)+)"; // one or more " <alt>" icons
  const NAME = "(.+?)";

  // Order matters: the more specific patterns come first.
  const PATTERNS = [
    ["rolled", new RegExp(`^${NAME} rolled <dice_(\\d)> <dice_(\\d)>$`)],
    ["playerTrade", new RegExp(`^${NAME} gave${ICONS} and got${ICONS} from ${NAME}$`)],
    ["bankTrade", new RegExp(`^${NAME} gave bank${ICONS} and took${ICONS}$`)],
    // A trade offer: nothing moves, but the offered cards are in the offerer's hand.
    ["offer", new RegExp(`^${NAME} wants to give${ICONS} for${ICONS}$`)],
    ["tookFromBank", new RegExp(`^${NAME} took from bank${ICONS}$`)],
    ["startingResources", new RegExp(`^${NAME} received starting resources${ICONS}$`)],
    ["got", new RegExp(`^${NAME} got${ICONS}$`)],
    ["discarded", new RegExp(`^${NAME} discarded${ICONS}$`)],
    ["stoleFromYou", new RegExp(`^${NAME} stole${ICONS} from you$`)],
    ["youStole", new RegExp(`^You stole${ICONS} from ${NAME}$`)],
    ["hiddenSteal", new RegExp(`^${NAME} stole <Resource Card> from ${NAME}$`)],
    ["built", new RegExp(`^${NAME} built an? (Road|Settlement|City)\\b`)],
    // Free placements: setup, and Road Building's two roads. Nothing is paid.
    ["placed", new RegExp(`^${NAME} placed an? (Road|Settlement|City)\\b`)],
    ["bought", new RegExp(`^${NAME} bought <Development Card>$`)],
    ["robberMoved", new RegExp(`^${NAME} moved Robber <robber> to <prob_(\\d+)> <(\\w+) tile>$`)],
    ["blocked", new RegExp(`^<prob_(\\d+)> <(\\w+) tile> is blocked by the Robber`)],
    // Monopoly result: "Serge stole 3 <grain>" (N cards of one type, from everyone)
    ["monopoly", new RegExp(`^${NAME} stole (\\d+)${ICONS}$`)],
    // Row text is "Fi usedKnight <Knight>" (card name glued to "used").
    ["used", new RegExp(`^${NAME} used ?(.*?) <([^>]+)>$`)],
  ];

  // Avatar icons that colonist puts in front of the player name in each row.
  const clean = (line) => line.replace(/<(?:Player avatar|bot)>/g, "").replace(/\s+/g, " ").trim();

  const icons = (s) => [...s.matchAll(/<([^>]+)>/g)].map((m) => m[1]);
  const resList = (s) =>
    icons(s).map((a) => a.toLowerCase()).filter((a) => RES.includes(a));
  const sum = (obj) => RES.reduce((n, r) => n + obj[r], 0);
  const zero = () => Object.fromEntries(RES.map((r) => [r, 0]));

  // ---------------------------------------------------------------------------
  // Possible-worlds engine.
  // A "world" is one complete, consistent guess of every player's hand (5 counts
  // per player). Public events change all worlds the same way; a hidden steal
  // branches each world into one world per card type the victim could have lost.
  // An event that needs cards a world does not have (a build, trade, discard...)
  // deletes that world, and Monopoly keeps only worlds where the other players'
  // cards of that type add up to the announced number. What is left tells us,
  // for every player and type, the real minimum and maximum they can hold.
  // Each world also has a probability (wts, same order as list, sums to 1): a
  // hidden steal takes a random card, so a victim holding 3 lumber and 1 brick
  // becomes "lost a lumber" with weight 3/4 and "lost the brick" with 1/4.
  // Every other event only keeps or drops worlds, so the weights stay exact.
  // Each world also remembers which type every hidden steal took in it (tags,
  // same order as list: tags[i][sid] = type index), so a stolen card can be
  // shown on its own while nothing has mixed it with the thief's other cards.
  function createWorlds(opts = {}) {
    const MAX_WORLDS = opts.maxWorlds || 60000; // stress test with ~20x normal steals peaked near 19k
    const names = [];
    const idx = new Map();
    let list = [new Int8Array(0)];
    let wts = [1];
    let tags = [new Int8Array(0)];
    // sid -> { thief, victim, dead }. dead: two worlds that disagreed on this
    // steal's type were merged, so it can no longer be told apart.
    const steals = [];
    const status = { overflow: false, degraded: false, maxSeen: 1 };

    const live = () => !status.overflow && !status.degraded;
    const keyOf = (w) => w.join(",");

    function slot(name) {
      let i = idx.get(name);
      if (i === undefined) {
        i = names.length;
        names.push(name);
        idx.set(name, i);
        const len = names.length * 5;
        list = list.map((w) => {
          const x = new Int8Array(len);
          x.set(w);
          return x;
        });
      }
      return i * 5;
    }

    function settle(next, nextW, nextT, why) {
      if (next.length === 0) {
        // No world explains the log: something is missing/unknown. Stop trusting
        // this engine; the caller falls back to the simple tracker.
        status.degraded = true;
        status.why = why;
        list = [];
        wts = [];
        tags = [];
        return false;
      }
      if (next.length > MAX_WORLDS) {
        status.overflow = true;
        list = [];
        wts = [];
        tags = [];
        return false;
      }
      const z = nextW.reduce((a, b) => a + b, 0);
      list = next;
      wts = z > 0 ? nextW.map((w) => w / z) : next.map(() => 1 / next.length);
      tags = nextT;
      if (next.length > status.maxSeen) status.maxSeen = next.length;
      return true;
    }

    // Two worlds with the same hands are being merged into one: any steal they
    // disagree on can no longer be told apart.
    function mergeTags(a, b) {
      for (let s = 0; s < a.length; s++) if (a[s] !== b[s]) steals[s].dead = true;
    }

    function counts(types) {
      const c = new Int8Array(5);
      types.forEach((t) => c[RES.indexOf(t)]++);
      return c;
    }

    return {
      status,
      size: () => list.length,
      add(name, types) {
        if (!live()) return;
        const o = slot(name);
        const c = counts(types);
        for (const w of list) for (let k = 0; k < 5; k++) w[o + k] += c[k];
      },
      remove(name, types) {
        if (!live()) return;
        const o = slot(name);
        const c = counts(types);
        const next = [];
        const nextW = [];
        const nextT = [];
        list.forEach((w, i) => {
          for (let k = 0; k < 5; k++) if (w[o + k] < c[k]) return;
          for (let k = 0; k < 5; k++) w[o + k] -= c[k];
          next.push(w);
          nextW.push(wts[i]);
          nextT.push(tags[i]);
        });
        settle(next, nextW, nextT, `${name} spent cards no world has`);
      },
      // `name` showed that they hold `types` (a trade offer: colonist only lets a
      // player offer cards from their hand). Worlds where they don't are dropped.
      // If no world has them, nothing changes and false is returned.
      holds(name, types) {
        if (!live()) return false;
        const c = counts(types);
        if (!idx.has(name)) return c.every((x) => x === 0);
        const o = idx.get(name) * 5;
        const keep = list.map((w) => c.every((x, k) => w[o + k] >= x));
        if (!keep.includes(true)) return false;
        if (keep.every(Boolean)) return true;
        list = list.filter((w, i) => keep[i]);
        const nextW = wts.filter((w, i) => keep[i]);
        const z = nextW.reduce((a, b) => a + b, 0);
        wts = nextW.map((w) => w / z);
        tags = tags.filter((t, i) => keep[i]);
        return true;
      },
      // can `name` hold `types` in at least one world? (false with the engine off)
      canPay(name, types) {
        if (!live()) return false;
        const c = counts(types);
        if (!idx.has(name)) return c.every((x) => x === 0);
        const o = idx.get(name) * 5;
        return list.some((w) => c.every((x, k) => w[o + k] >= x));
      },
      steal(thief, victim) {
        if (!live()) return;
        const t = slot(thief);
        const v = slot(victim);
        const sid = steals.length;
        steals.push({ thief, victim, dead: false });
        const seen = new Map(); // world key -> index in next
        const next = [];
        const nextW = [];
        const nextT = [];
        list.forEach((w, i) => {
          let tot = 0;
          for (let k = 0; k < 5; k++) tot += w[v + k];
          for (let k = 0; k < 5; k++) {
            if (w[v + k] <= 0) continue;
            const nw = w.slice();
            nw[v + k]--;
            nw[t + k]++;
            const p = (wts[i] * w[v + k]) / tot; // a random card: k with chance count/total
            const nt = new Int8Array(sid + 1);
            nt.set(tags[i]);
            nt[sid] = k;
            const key = keyOf(nw);
            const j = seen.get(key);
            if (j === undefined) {
              seen.set(key, next.length);
              next.push(nw);
              nextW.push(p);
              nextT.push(nt);
            } else {
              nextW[j] += p;
              mergeTags(nextT[j], nt);
            }
          }
        });
        settle(next, nextW, nextT, `${victim} had no card to steal`);
      },
      monopoly(thief, type, n) {
        if (!live()) return;
        const t = slot(thief);
        const k = RES.indexOf(type);
        const seen = new Map();
        const next = [];
        const nextW = [];
        const nextT = [];
        list.forEach((w, i) => {
          let s = 0;
          for (let p = 0; p < names.length; p++) if (p * 5 !== t) s += w[p * 5 + k];
          if (s !== n) return;
          const nw = w.slice();
          for (let p = 0; p < names.length; p++) if (p * 5 !== t) nw[p * 5 + k] = 0;
          nw[t + k] += n;
          const key = keyOf(nw);
          const j = seen.get(key);
          if (j === undefined) {
            seen.set(key, next.length);
            next.push(nw);
            nextW.push(wts[i]);
            nextT.push(tags[i]);
          } else {
            nextW[j] += wts[i];
            mergeTags(nextT[j], tags[i]);
          }
        });
        settle(next, nextW, nextT, `Monopoly of ${n} ${type} matches no world`);
      },
      // Hand sizes shown by colonist's panel are ground truth. Call this only
      // when the log has caught up with the panel. Worlds whose total for a
      // player differs are dropped; if no world matches we keep everything
      // (the log is probably incomplete) and report false.
      observe(hands) {
        if (!live()) return false;
        const checks = Object.entries(hands)
          .filter(([n, c]) => idx.has(n) && Number.isFinite(c))
          .map(([n, c]) => [idx.get(n) * 5, c]);
        const keep = list.map((w) =>
          checks.every(([o, c]) => w[o] + w[o + 1] + w[o + 2] + w[o + 3] + w[o + 4] === c)
        );
        if (!keep.includes(true)) return false;
        const next = list.filter((w, i) => keep[i]);
        const nextW = wts.filter((w, i) => keep[i]);
        const z = nextW.reduce((a, b) => a + b, 0);
        list = next;
        wts = nextW.map((w) => w / z);
        tags = tags.filter((t, i) => keep[i]);
        return true;
      },
      // Chance that one random card taken from `name` is each type (p[k], over
      // the weighted worlds), and the chance they hold no card at all (empty).
      odds(name) {
        if (!live() || !idx.has(name)) return null;
        const o = idx.get(name) * 5;
        const p = [0, 0, 0, 0, 0];
        let empty = 0;
        list.forEach((w, i) => {
          const tot = w[o] + w[o + 1] + w[o + 2] + w[o + 3] + w[o + 4];
          if (tot === 0) empty += wts[i];
          else for (let k = 0; k < 5; k++) p[k] += (wts[i] * w[o + k]) / tot;
        });
        return { p, empty };
      },
      // smallest/largest total hand size over all surviving worlds, or null
      totalRange(name) {
        if (!live() || !idx.has(name)) return null;
        const o = idx.get(name) * 5;
        let lo = 1e9;
        let hi = -1;
        for (const w of list) {
          const s = w[o] + w[o + 1] + w[o + 2] + w[o + 3] + w[o + 4];
          if (s < lo) lo = s;
          if (s > hi) hi = s;
        }
        return { min: lo, max: hi };
      },
      // per-type min/max over all surviving worlds, or null if not trustworthy
      range(name) {
        if (!live()) return null;
        const o = idx.has(name) ? idx.get(name) * 5 : -1;
        const min = [0, 0, 0, 0, 0];
        const max = [0, 0, 0, 0, 0];
        if (o < 0) return { min, max };
        for (let k = 0; k < 5; k++) {
          let lo = 127;
          let hi = 0;
          for (const w of list) {
            if (w[o + k] < lo) lo = w[o + k];
            if (w[o + k] > hi) hi = w[o + k];
          }
          min[k] = lo;
          max[k] = hi;
        }
        return { min, max };
      },
      // weighted distribution of `name`'s whole hand: Map "l,b,w,g,o" -> chance, or null
      hands(name) {
        if (!live() || !idx.has(name)) return null;
        const o = idx.get(name) * 5;
        const m = new Map();
        list.forEach((w, i) => {
          const key = `${w[o]},${w[o + 1]},${w[o + 2]},${w[o + 3]},${w[o + 4]}`;
          m.set(key, (m.get(key) || 0) + wts[i]);
        });
        return m;
      },
      // `name`'s unknown cards (hand minus the per-type minimum) split by the
      // hidden steals they came from, where that is exact. A steal's card stands
      // on its own when, in every world, it is among the unknown cards and its
      // type is independent of all the other unknown cards; it stops when the
      // thief loses a card that could have been it or another unknown one.
      // { rest: Map "l,b,w,g,o" -> chance (the cards that stay together),
      //   steals: [{ sid, victim, p: [chance of each type] }] (oldest first) }, or null.
      groups(name) {
        if (!live() || !idx.has(name)) return null;
        const o = idx.get(name) * 5;
        const min = [127, 127, 127, 127, 127];
        for (const w of list) for (let k = 0; k < 5; k++) if (w[o + k] < min[k]) min[k] = w[o + k];
        // this player's steals still told apart whose type is not settled yet
        const cand = [];
        steals.forEach((s, sid) => {
          if (s.thief !== name || s.dead) return;
          const t0 = tags[0][sid];
          if (tags.some((tg) => tg[sid] !== t0)) cand.push(sid);
        });
        const split = (S) => {
          const joint = new Map();
          const rest = new Map();
          const sp = S.map(() => [0, 0, 0, 0, 0]);
          for (let i = 0; i < list.length; i++) {
            const e = [];
            for (let k = 0; k < 5; k++) e.push(list[i][o + k] - min[k]);
            for (const sid of S) if (--e[tags[i][sid]] < 0) return null; // that card is not among the unknown ones here
            const rk = e.join(",");
            const jk = rk + "|" + S.map((sid) => tags[i][sid]).join(",");
            joint.set(jk, (joint.get(jk) || 0) + wts[i]);
            rest.set(rk, (rest.get(rk) || 0) + wts[i]);
            S.forEach((sid, j) => (sp[j][tags[i][sid]] += wts[i]));
          }
          // independent: every combination's chance is the product of its parts'
          let covered = 0;
          for (const [jk, p] of joint) {
            const [rk, ts] = jk.split("|");
            let q = rest.get(rk);
            if (S.length) ts.split(",").forEach((t, j) => (q *= sp[j][+t]));
            if (Math.abs(p - q) > 1e-9) return null;
            covered += q;
          }
          if (covered < 1 - 1e-9) return null;
          return { rest, steals: S.map((sid, j) => ({ sid, victim: steals[sid].victim, p: sp[j] })) };
        };
        // A steal that can't stand alone can't be part of a bigger split either,
        // so test each one alone first, then the largest group (newest kept longest).
        const single = cand.filter((sid) => split([sid]));
        for (let k = single.length; k > 0; k--) {
          const r = split(single.slice(-k));
          if (r) return r;
        }
        return split([]);
      },
      // weighted average count of each type over the surviving worlds, or null
      mean(name) {
        if (!live()) return null;
        const m = [0, 0, 0, 0, 0];
        if (!idx.has(name)) return m;
        const o = idx.get(name) * 5;
        list.forEach((w, i) => {
          for (let k = 0; k < 5; k++) m[k] += wts[i] * w[o + k];
        });
        return m;
      },
    };
  }

  function createTracker(opts = {}) {
    const worlds = createWorlds({ maxWorlds: opts.maxWorlds });
    const state = {
      me: opts.me || null,
      players: {},
      pieces: {}, // name -> { settlements, cities } on the board
      lastRollSum: null,
      robber: null, // { num, res, by }
      hexes: {}, // "8:grain" -> { num, res, owners:Set, blockedCount }
      blocked: [], // robber-blocked production events
      bankTrades: [], // every bank trade: { player, gave[], took[], roll }
      ports: {}, // name -> { has: Set, no: Set } of port keys ("3:1", "lumber", ...), see portTrade()
      warnings: [],
      lastRoller: null, // whose turn it is (the last player who rolled)
      devBought: 0, // dev cards bought by everyone so far
      devPlayed: {}, // type -> how many were played (public)
      myDev: null, // my own held dev cards by type, once we can read them
      robberPending: false, // I rolled a 7 this turn and have not moved the robber yet
      // Turn order = who placed a first settlement, in order, during setup (the
      // first repeat starts the snake back). Done once the round is complete.
      turnOrder: [],
      turnOrderDone: false,
      currentPlayer: null, // whose turn it is (page's turn marker, else the last roller)
      myTurnSnap: null, // { turn, dev }: my dev cards when my turn began (all playable)
    };
    const hazard = { ...DEV_HAZARD, ...(opts.hazard || {}) };
    let devVersion = 0; // bumped whenever the dev card picture may have changed
    let devSeq = 0; // ids for held dev cards (stable while held; replays give the same ids)
    let devCache = null;
    let handVersion = 0; // bumped whenever anyone's hand may have changed
    let oddsCache = { v: -1, m: new Map() };
    let comboCache = { v: -1, m: new Map() };
    let groupCache = { v: -1, m: new Map() };

    const warn = (msg) => state.warnings.push(msg);
    const who = (n) => (n === "You" ? state.me : n);

    // Buildings on the board per player (an upgrade to a city removes a
    // settlement). Kept apart from `players`: creating players at setup would
    // change their order, which the simple model's Monopoly split depends on.
    const pieces = (name) => (state.pieces[name] ||= { settlements: 0, cities: 0, roads: 0 });

    // Ports, inferred from bank-trade rates (tracked only, never displayed; the
    // page shows no ports). The game always applies a player's best rate, so a
    // message has one rate = cards given / cards taken:
    //   2: owns the 2:1 port of every type given (one owner per game)
    //   3: owns a 3:1 port, and no 2:1 port for the types given
    //   4: no 3:1 port and no 2:1 port for the types given
    // Owning is permanent (`has`). Not owning (`no`) holds until that player's
    // next settlement: only a new settlement can reach a new port (a city sits
    // on the same corner). A rate other than 2, 3 or 4, or a type whose count
    // isn't a multiple of it, is flagged and teaches nothing.
    const portRec = (name) => (state.ports[name] ||= { has: new Set(), no: new Set() });
    const portName = (k) => (k === "3:1" ? "a 3:1 port" : `the ${k} 2:1 port`);

    function portTrade(p, gave, took) {
      const rate = gave.length / took.length;
      const types = [...new Set(gave)];
      const count = (r) => gave.filter((x) => x === r).length;
      if (![2, 3, 4].includes(rate) || types.some((r) => count(r) % rate)) {
        warn(`port: ${p} gave the bank ${gave.length} for ${took.length}, not one 2:1, 3:1 or 4:1 rate`);
        return;
      }
      const P = portRec(p);
      const owns = rate === 2 ? types : rate === 3 ? ["3:1"] : [];
      const lacks = rate === 4 ? ["3:1", ...types] : rate === 3 ? types : [];
      for (const k of owns) {
        if (P.no.has(k)) warn(`port: ${p} traded with ${portName(k)} but had none at an earlier trade, with no settlement since`);
        if (k !== "3:1") {
          for (const [other, o] of Object.entries(state.ports)) {
            if (other !== p && o.has.has(k)) warn(`port: ${p} and ${other} both traded ${k} at 2:1 (one owner per game)`);
          }
        }
        P.no.delete(k);
        P.has.add(k);
      }
      for (const k of lacks) {
        if (P.has.has(k)) warn(`port: ${p} traded at ${rate}:1 but owns ${portName(k)}`);
        else P.no.add(k);
      }
    }

    // A new settlement may stand on a port: forget what the player lacked.
    const portSettled = (name) => state.ports[name] && state.ports[name].no.clear();

    // What we know of a player's ports: { "3:1", lumber, brick, wool, grain, ore }
    // each true (owns it), false (doesn't, as of now) or null (unknown). A 2:1
    // port another player owns is false for everyone else.
    function ports(name) {
      const P = state.ports[name] || { has: new Set(), no: new Set() };
      const out = {};
      for (const k of ["3:1", ...RES]) {
        const taken = k !== "3:1" && Object.entries(state.ports).some(([o, r]) => o !== name && r.has.has(k));
        out[k] = P.has.has(k) ? true : taken || P.no.has(k) ? false : null;
      }
      return out;
    }

    function ensure(name) {
      if (!state.players[name]) {
        state.players[name] = {
          name,
          res: zero(), // known cards (upper bound while `lost` > 0)
          unknown: 0, // cards held whose type we do not know
          lost: 0, // cards gone whose type we do not know
          devUsed: 0,
          devPlayed: {}, // { Knight: 2, Monopoly: 1, ... }
          rolls: 0, // turns this player has started (one roll per turn)
          devCards: [], // dev cards held and unplayed: { turn, id } (turn = when bought)
          devPlayedTurns: new Set(), // turns in which they played a dev card
          // Candidate resource types for each uncertain card (same length as the
          // counts above): lostSets[i] = types the i-th lost card might have been,
          // unknownSets[i] = types the i-th unknown card we hold might be.
          lostSets: [],
          unknownSets: [],
        };
      }
      return state.players[name];
    }

    // Remove one candidate set from `sets`, preferring one that includes `r`.
    function takeSet(sets, r) {
      let i = r ? sets.findIndex((s) => s.includes(r)) : -1;
      if (i < 0) i = 0;
      if (sets.length) sets.splice(i, 1);
    }

    const total = (name) => {
      const p = state.players[name];
      return p ? sum(p.res) - p.lost + p.unknown : 0;
    };

    function addCards(name, list) {
      const p = ensure(name);
      list.forEach((r) => p.res[r]++);
      worlds.add(name, list);
    }

    function removeCards(name, list) {
      removeSimple(name, list);
      worlds.remove(name, list);
    }

    function removeSimple(name, list) {
      const p = ensure(name);
      list.forEach((r) => {
        if (p.res[r] > 0) p.res[r]--;
        else if (p.unknown > 0) {
          p.unknown--; // resolves an unknown card
          takeSet(p.unknownSets, r);
        } else warn(`${name} lost a ${r} we did not know they had`);
      });
    }

    function canAfford(p, cost) {
      let short = 0;
      RES.forEach((r) => {
        short += Math.max(0, (cost[r] || 0) - p.res[r]);
      });
      return short <= p.unknown;
    }

    // Pay for a build or a dev card. Each model decides for itself whether the
    // player could pay: the simple model goes wrong after a Monopoly, and that
    // must not hide the payment from the worlds. Returns false if neither could.
    function spend(name, cost) {
      const list = [];
      RES.forEach((r) => {
        for (let i = 0; i < (cost[r] || 0); i++) list.push(r);
      });
      const simpleOk = canAfford(ensure(name), cost);
      const worldsOk = worlds.canPay(name, list);
      if (simpleOk) removeSimple(name, list);
      if (simpleOk || worldsOk) worlds.remove(name, list);
      return simpleOk || worldsOk;
    }

    function hiddenSteal(thief, victim) {
      const deduced = hiddenStealSimple(thief, victim);
      worlds.steal(thief, victim);
      return deduced;
    }

    function hiddenStealSimple(thief, victim) {
      const V = ensure(victim);
      const T = ensure(thief);
      if (V.unknown === 0 && V.lost === 0) {
        // Deducible when the victim holds only one type of card.
        const types = RES.filter((r) => V.res[r] > 0);
        if (types.length === 1) {
          V.res[types[0]]--;
          T.res[types[0]]++;
          return types[0];
        }
      }
      // Ambiguous: the card was one of the types the victim might hold.
      const cands = RES.filter(
        (r) => V.res[r] > 0 || V.unknownSets.some((s) => s.includes(r))
      );
      const set = cands.length ? cands : RES.slice();
      V.lost++;
      V.lostSets.push(set);
      T.unknown++;
      T.unknownSets.push(set.slice());
      return null;
    }

    function hex(num, res) {
      const key = `${num}:${res}`;
      if (!state.hexes[key]) state.hexes[key] = { num, res, owners: new Set(), blockedCount: 0 };
      return state.hexes[key];
    }

    // Monopoly: every other player loses all their cards of `r`; thief gets n.
    function monopoly(thief, r, n) {
      const others = Object.values(state.players).filter((p) => p.name !== thief);
      const removed = new Map();
      let remaining = n;
      others.forEach((p) => {
        removed.set(p.name, p.res[r]);
        remaining -= p.res[r];
        p.res[r] = 0;
      });
      if (remaining > 0) {
        // Shortfall: the rest were cards whose type we did not know.
        others.forEach((p) => {
          while (remaining > 0 && p.unknown > 0) {
            p.unknown--;
            takeSet(p.unknownSets, r);
            remaining--;
          }
        });
      } else if (remaining < 0) {
        // We counted more known cards than were really there: some of them were
        // cards an earlier hidden steal had already taken (`lost`). Give those back.
        let excess = -remaining;
        remaining = 0;
        others.forEach((p) => {
          const dec = Math.min(excess, p.lost, removed.get(p.name));
          p.lost -= dec;
          for (let i = 0; i < dec; i++) takeSet(p.lostSets, r);
          excess -= dec;
        });
        remaining = -excess;
      }
      if (remaining !== 0) warn(`${thief} Monopoly on ${r}: ${remaining} cards unaccounted for`);
      ensure(thief).res[r] += n;
      worlds.monopoly(thief, r, n);
    }

    // ---- development cards ------------------------------------------------
    // A player's turn number = how many times they have rolled. A play that
    // happens before their roll belongs to the turn they are about to start.
    const turnOf = (name) => ensure(name).rolls + (state.lastRoller === name ? 0 : 1);

    // How many chances has this held card had to be played and was not? Those are
    // the holder's finished turns after the purchase turn, minus turns where they
    // played a different dev card (only one per turn, so no chance for this one).
    function chancesMissed(p, card) {
      const finished = p.rolls - (state.lastRoller === p.name ? 1 : 0);
      let n = 0;
      for (let j = card.turn + 1; j <= finished; j++) if (!p.devPlayedTurns.has(j)) n++;
      return n;
    }

    // The holder's finished turns after the purchase turn (shown in the tooltip).
    const turnsHeld = (p, card) => Math.max(0, p.rolls - (state.lastRoller === p.name ? 1 : 0) - card.turn);

    function devBought(name) {
      const p = ensure(name);
      p.devCards.push({ turn: turnOf(name), id: ++devSeq });
      state.devBought++;
      devVersion++;
    }

    function devUsed(name, type) {
      const p = ensure(name);
      const turn = turnOf(name);
      // Which held card was it? Take the eligible one the model thinks is most
      // likely to be this type (an old card is more likely a Monopoly, a fresh
      // one a Knight), judged before this play is counted.
      const mine = devEstimate().cards[name] || [];
      let best = -1;
      let bestP = -1;
      p.devCards.forEach((c, i) => {
        if (c.turn >= turn) return; // cannot be played the turn it was bought
        const pr = mine[i] ? mine[i].dist[type] || 0 : 0;
        if (pr > bestP) {
          bestP = pr;
          best = i;
        }
      });
      if (best < 0 && p.devCards.length) best = 0;
      if (best >= 0) p.devCards.splice(best, 1);
      p.devPlayedTurns.add(turn);
      state.devPlayed[type] = (state.devPlayed[type] || 0) + 1;
      devVersion++;
    }

    // Per held card: chance of each type. Plus the chance that the NEXT card drawn
    // from the deck is each type (the deck = what is unaccounted for minus what
    // opponents are probably holding).
    function devEstimate() {
      if (devCache && devCache.v === devVersion) return devCache.value;
      const mine = state.myDev;
      const pool = DEV_TYPES.map((t) =>
        Math.max(0, DEV_TOTAL[t] - (state.devPlayed[t] || 0) - ((mine && mine[t]) || 0))
      );
      const entries = [];
      Object.values(state.players).forEach((p) => {
        if (mine && p.name === state.me) return; // our own cards are known
        p.devCards.forEach((c, i) => entries.push({ player: p.name, i, id: c.id, s: chancesMissed(p, c), held: turnsHeld(p, c) }));
      });
      const { marg } = estimateDev(pool, entries.map((e) => e.s), hazard);
      const cards = {};
      const heldExp = DEV_TYPES.map(() => 0);
      entries.forEach((e, k) => {
        const dist = {};
        DEV_TYPES.forEach((t, j) => {
          dist[t] = marg[k][j];
          heldExp[j] += marg[k][j];
        });
        (cards[e.player] ||= [])[e.i] = { dist, missed: e.s, held: e.held, id: e.id };
      });
      const deckExp = pool.map((n, j) => Math.max(0, n - heldExp[j]));
      const deckSum = deckExp.reduce((a, b) => a + b, 0);
      const chance = {};
      const unseen = {};
      DEV_TYPES.forEach((t, j) => {
        chance[t] = deckSum > 0 ? deckExp[j] / deckSum : 0;
        unseen[t] = pool[j];
      });
      // Bookkeeping: with every card tracked, unaccounted = deck + held entries.
      // (A tester saw the deck at 83% VP / 17% YoP, then the card bought from it
      // at 100%; with consistent counts those two are always equal.)
      const unaccounted = pool.reduce((a, b) => a + b, 0);
      const value = {
        cards,
        deck: { size: Math.max(0, DEV_CARDS - state.devBought), chance, unseen, expected: deckExp, unaccounted, held: entries.length },
        ownKnown: !!mine,
      };
      devCache = { v: devVersion, value };
      return value;
    }

    // A player's held cards that meet the "50% condition" (see VP_SHOW), in
    // purchase order: { cards: [{ i, id, p, held }], sure } with i the card's
    // index in devEstimate().cards[name], p its VP chance (climbs while it is
    // held: a Knight or Year of Plenty would have been played) and sure how many
    // are at VP_SURE or more; null when none qualifies.
    function vpSuspects(name) {
      const pc = (p) => Math.round(p * 100); // as the tooltips show it
      const cards = (devEstimate().cards[name] || [])
        .map((c, i) => c && { i, id: c.id, p: c.dist["Victory Point"], held: c.held, dist: c.dist })
        .filter((c) => c && pc(c.p) >= pc(VP_SHOW) && DEV_TYPES.every((t) => t === "Victory Point" || pc(c.dist[t]) <= pc(VP_OTHER_MAX)))
        .map(({ i, id, p, held }) => ({ i, id, p, held }));
      if (!cards.length) return null;
      return { cards, sure: cards.filter((c) => pc(c.p) >= pc(VP_SURE)).length };
    }

    // ---- robbing -------------------------------------------------------------
    // Chance that one random card taken from `name` (robber after a 7, or a
    // Knight) is each resource, e.g. { lumber: 0.5, brick: 0.25, ... }. The rest
    // up to 1 is the chance they hold no card. null = player not seen yet.
    function stealOdds(name) {
      const p = state.players[name];
      if (!p) return null;
      if (oddsCache.v !== handVersion) oddsCache = { v: handVersion, m: new Map() };
      if (oddsCache.m.has(name)) return oddsCache.m.get(name);
      let out;
      const w = worlds.odds(name);
      if (w) out = Object.fromEntries(RES.map((r, k) => [r, w.p[k]]));
      else {
        // Engine off: spread each uncertain card evenly over its candidate types.
        const share = (sets, r) => sets.reduce((s, set) => s + (set.includes(r) ? 1 / set.length : 0), 0);
        const e = RES.map((r) => Math.max(0, p.res[r] + share(p.unknownSets, r) - share(p.lostSets, r)));
        const z = e.reduce((a, b) => a + b, 0);
        out = Object.fromEntries(RES.map((r, k) => [r, z > 0 ? e[k] / z : 0]));
      }
      oddsCache.m.set(name, out);
      return out;
    }

    // ---- turns ----------------------------------------------------------------
    // Whose turn it is. content.js reports the page's turn marker; a roll or a
    // dev card play in the log also says it. When it becomes my turn, every dev
    // card I hold was bought on an earlier turn, so all of them are playable.
    function setCurrentPlayer(name) {
      if (!name || name === state.currentPlayer) return;
      const prev = state.currentPlayer;
      state.currentPlayer = name;
      if (name !== state.me) state.robberPending = false;
      else if (prev && prev !== name) snapMyTurn();
    }

    function snapMyTurn() {
      const turn = turnOf(state.me);
      if (state.myTurnSnap && state.myTurnSnap.turn === turn) return;
      state.myTurnSnap = { turn, dev: state.myDev ? { ...state.myDev } : null };
    }

    // The player whose turn comes before `name` (null until the order is known).
    function playerBefore(name) {
      const o = state.turnOrder;
      const i = o.indexOf(name);
      return state.turnOrderDone && i >= 0 ? o[(i + o.length - 1) % o.length] : null;
    }

    // Setup is over: someone rolled, or every player in the turn order has put
    // down both setup settlements AND both setup roads (the last player's second
    // road ends it; before that, the user may still owe a road).
    function setupDone() {
      if (state.lastRoller) return true;
      const o = state.turnOrder;
      return state.turnOrderDone && o.length > 0 && o.every((p) => pieces(p).settlements >= 2 && pieces(p).roads >= 2);
    }

    // Can `name` put down one more of `kind`? A city also needs a settlement to replace.
    function hasPiece(name, kind) {
      const B = pieces(name);
      return kind === "city" ? B.cities < PIECES.city && B.settlements > 0 : B.settlements < PIECES.settlement;
    }

    // On my turn, when I can move the robber (I rolled a 7 and have not moved it
    // yet, or I hold a Knight I may play this turn), I still have the piece, and
    // I am one card short of a settlement or a city, or two short when one bank
    // trade from my spare cards covers one of them (at my best known rate: 2:1
    // with that type's port, 3:1 with a 3:1 port, else 4:1; the cheapest rate
    // first): the opponent with the best chance (at least ROB_MIN) of giving me a
    // card I still miss, per piece; several only when their odds are equal (the
    // user's rule: one marker unless tied, or a city steal and a settlement steal
    // from different players). With a trade, each opponent gets the missing card
    // they are most likely to give, and the trade buys the other. Returns null or
    // { reason: "7" | "Knight", targets: { settlement?, city? } } with each
    // target = { players, picks: { name: { res, p, trade } }, spotUnknown },
    // trade = null or { rate, give, get } (give `rate` cards of `give` for one `get`).
    // spotUnknown: a settlement also needs a legal spot (distance rule, a road),
    // which the log can't tell us; a city only needs one of my settlements.
    function robAdvice() {
      const me = state.me;
      const P = me && state.players[me];
      if (!P || state.currentPlayer !== me) return null;
      const turn = turnOf(me);
      let knight = false;
      if (state.myDev && !P.devPlayedTurns.has(turn)) {
        const now = state.myDev.Knight || 0;
        // Cards bought this turn can't be played. Without a snapshot from the
        // start of my turn (e.g. after a reload), assume every card bought this
        // turn might be one of the Knights.
        const snap = state.myTurnSnap && state.myTurnSnap.turn === turn ? state.myTurnSnap.dev : null;
        const start = snap ? snap.Knight || 0 : now - P.devCards.filter((c) => c.turn === turn).length;
        knight = Math.min(now, start) > 0;
      }
      if (!state.robberPending && !knight) return null;
      const myPorts = ports(me);
      const rate = (t) => (myPorts[t] ? 2 : myPorts["3:1"] ? 3 : 4);
      const targets = {};
      for (const kind of ["settlement", "city"]) {
        if (!hasPiece(me, kind)) continue;
        const cost = COSTS[kind];
        const spare = (t) => P.res[t] - (cost[t] || 0);
        const need = {}; // type -> cards missing
        RES.forEach((r) => spare(r) < 0 && (need[r] = -spare(r)));
        const missing = Object.values(need).reduce((a, b) => a + b, 0);
        if (missing !== 1 && missing !== 2) continue;
        let give = null;
        if (missing === 2) {
          give = RES.filter((t) => !need[t] && spare(t) >= rate(t)).sort((a, b) => rate(a) - rate(b) || spare(b) - spare(a))[0];
          if (!give) continue;
        }
        const picks = {};
        Object.keys(state.players).forEach((name) => {
          if (name === me) return;
          const o = stealOdds(name);
          if (!o) return;
          const r = Object.keys(need).reduce((best, x) => (o[x] > o[best] ? x : best));
          if (o[r] < ROB_MIN - 1e-9) return;
          // The trade buys whatever is still missing once the steal brings r.
          const get = give && Object.keys(need).find((x) => need[x] > (x === r ? 1 : 0));
          picks[name] = { res: r, p: o[r], trade: give ? { rate: rate(give), give, get } : null };
        });
        const best = Math.max(...Object.values(picks).map((x) => x.p));
        const players = Object.keys(picks).filter((n) => picks[n].p >= best - 1e-9);
        if (players.length) {
          const top = Object.fromEntries(players.map((n) => [n, picks[n]]));
          targets[kind] = { players, picks: top, spotUnknown: kind === "settlement" };
        }
      }
      if (!Object.keys(targets).length) return null;
      return { reason: state.robberPending ? "7" : "Knight", targets };
    }

    function processLine(rawLine) {
      const line = clean(rawLine);
      handVersion++;
      for (const [type, re] of PATTERNS) {
        const m = line.match(re);
        if (!m) continue;
        switch (type) {
          case "rolled": {
            state.lastRollSum = Number(m[2]) + Number(m[3]);
            const p = who(m[1]);
            ensure(p).rolls++;
            state.lastRoller = p;
            if (state.turnOrder.length) state.turnOrderDone = true; // setup is over
            setCurrentPlayer(p);
            state.robberPending = p === state.me && state.lastRollSum === 7;
            if (p === state.me) snapMyTurn(); // nothing can be bought before the roll
            devVersion++;
            return { type, player: m[1], sum: state.lastRollSum };
          }
          case "placed": {
            const p = who(m[1]);
            if (m[2] === "Settlement" && !state.turnOrderDone && !state.lastRoller) {
              if (state.turnOrder.includes(p)) state.turnOrderDone = true;
              else state.turnOrder.push(p);
            }
            if (m[2] === "Settlement") {
              pieces(p).settlements++;
              portSettled(p);
            } else if (m[2] === "City") pieces(p).cities++;
            else if (m[2] === "Road") pieces(p).roads++;
            return { type, player: p, kind: m[2].toLowerCase() };
          }
          case "playerTrade": {
            const a = who(m[1]);
            const b = who(m[4]);
            removeCards(a, resList(m[2]));
            addCards(b, resList(m[2]));
            removeCards(b, resList(m[3]));
            addCards(a, resList(m[3]));
            return { type, a, b };
          }
          case "bankTrade": {
            const p = who(m[1]);
            const gave = resList(m[2]);
            const took = resList(m[3]);
            removeCards(p, gave);
            addCards(p, took);
            state.bankTrades.push({ player: p, gave, took, roll: state.lastRollSum });
            portTrade(p, gave, took);
            return { type, player: p, gave: gave.length, took: took.length };
          }
          case "offer": {
            // Colonist only lets a player offer cards from their hand, so an offer
            // drops the worlds where the offerer lacks them (checked on the
            // recorded games: 214 opponent offers, none of cards the tracker had
            // ruled out). It can settle "?" cards even if the trade never happens.
            const p = who(m[1]);
            const give = resList(m[2]);
            if (p !== state.me && worlds.size() > 0 && !worlds.holds(p, give)) warn(`${p} offered ${give.join(" ")}, which no possible hand of theirs holds`);
            // The wanted side: colonist refuses an offer when the bank holds all
            // 19 of a wanted type (its shared bundle, getNoOneHasWantedResourceError
            // / doesASinglePlayerHaveResourceCard), so at least one is in SOME hand:
            // the offerer's own and yours count too (in the recorded games 23% of
            // opponent offers asked for a type the offerer surely held). The log
            // already gives each type's total over all hands exactly, so this
            // teaches nothing new; a zero total means rows were missed, or that
            // the room hides the bank: then colonist allows any offer (its
            // bundle: hideBankCards). A beta tester's rooms did (2026-10-16:
            // 13 such offers with complete accounting and no other problem).
            if (worlds.size() > 0) {
              const names = Object.keys(state.players);
              new Set(resList(m[3])).forEach((t) => {
                const k = RES.indexOf(t);
                const total = names.reduce((s, n) => s + worlds.mean(n)[k], 0);
                if (total < 0.5) warn(`${p} asked for ${t}, but by the log no hand holds any: missed rows, or the game hides the bank (colonist then allows any offer)`);
              });
            }
            return { type, player: p, give, want: resList(m[3]) };
          }
          case "tookFromBank":
          case "startingResources": {
            addCards(who(m[1]), resList(m[2]));
            return { type, player: m[1] };
          }
          case "got": {
            const p = who(m[1]);
            const list = resList(m[2]);
            addCards(p, list);
            if (state.lastRollSum) {
              new Set(list).forEach((r) => hex(state.lastRollSum, r).owners.add(p));
            }
            return { type, player: p };
          }
          case "discarded": {
            removeCards(who(m[1]), resList(m[2]));
            return { type, player: m[1] };
          }
          case "stoleFromYou": {
            const list = resList(m[2]);
            removeCards(state.me, list);
            addCards(m[1], list);
            return { type, thief: m[1], victim: state.me };
          }
          case "youStole": {
            const list = resList(m[1]);
            removeCards(m[2], list);
            addCards(state.me, list);
            return { type, thief: state.me, victim: m[2] };
          }
          case "hiddenSteal": {
            const deduced = hiddenSteal(who(m[1]), who(m[2]));
            return { type, thief: m[1], victim: m[2], deduced };
          }
          case "built": {
            const p = who(m[1]);
            const kind = m[2].toLowerCase();
            if (!spend(p, COSTS[kind])) warn(`${p} built a ${kind} we could not pay for (free? Road Building)`);
            const B = pieces(p);
            if (kind === "road") B.roads++;
            else if (kind === "settlement") {
              B.settlements++;
              portSettled(p);
            } else if (kind === "city") {
              B.settlements = Math.max(0, B.settlements - 1); // back to the pool
              B.cities++;
            }
            return { type, player: p, kind };
          }
          case "bought": {
            const p = who(m[1]);
            if (!spend(p, COSTS.devcard)) warn(`${p} bought a dev card we could not pay for`);
            devBought(p);
            return { type, player: p };
          }
          case "robberMoved": {
            if (who(m[1]) === state.me) state.robberPending = false;
            state.robber = { num: Number(m[2]), res: m[3].toLowerCase(), by: m[1] };
            return { type, ...state.robber };
          }
          case "blocked": {
            const h = hex(Number(m[1]), m[2].toLowerCase());
            h.blockedCount++;
            state.blocked.push({ num: h.num, res: h.res });
            return { type, num: h.num, res: h.res };
          }
          case "monopoly": {
            const r = resList(m[3])[0];
            if (!r) return null;
            monopoly(who(m[1]), r, Number(m[2]));
            return { type, player: m[1], res: r, n: Number(m[2]) };
          }
          case "used": {
            const P = ensure(who(m[1]));
            setCurrentPlayer(P.name); // a dev card is only played on your own turn
            P.devUsed++;
            P.devPlayed[m[3]] = (P.devPlayed[m[3]] || 0) + 1;
            devUsed(P.name, m[3]);
            return { type, player: m[1], card: m[3] };
          }
        }
      }
      return null; // chat, offers, setup placement, etc. - nothing to track
    }

    function snapshot() {
      return Object.values(state.players).map((p) => ({
        name: p.name,
        ...p.res,
        unknown: p.unknown,
        lost: p.lost,
        dev: JSON.stringify(p.devPlayed),
        total: total(p.name),
      }));
    }

    // Robber-blocked cards we can attribute so far (lower bound: 1 per building).
    function blockedFor(name) {
      return state.blocked.filter((b) => state.hexes[`${b.num}:${b.res}`].owners.has(name)).length;
    }

    // What the UI shows for one player (mirrors colonist's own inventory):
    //   res[t]   known count (upper bound while minus[t] > 0)
    //   minus[t] "-n": up to n of these might not really be there
    //   plus[t]  "+n": up to n of this type might have been added
    //   uncertain: any +/- marker is visible
    function inspectSimple(name) {
      const p = state.players[name];
      const res = zero();
      const minus = zero();
      const plus = zero();
      if (p) {
        RES.forEach((t) => {
          res[t] = p.res[t];
          minus[t] = Math.min(res[t], p.lostSets.filter((s) => s.includes(t)).length);
          plus[t] = p.unknownSets.filter((s) => s.includes(t)).length;
        });
      }
      const uncertain = RES.some((t) => minus[t] > 0 || plus[t] > 0);
      return { res, minus, plus, uncertain, source: "simple" };
    }

    // Same shape, but from the possible-worlds engine: for each type the real
    // [min, max] the player can hold. The shown count is the simple tracker's
    // count pulled into that range, -n = how far it may be too high, +n = how
    // far it may be too low. Types that are certain show no marker at all.
    function inspect(name) {
      const rng = worlds.range(name);
      if (!rng) return inspectSimple(name); // engine overflowed/degraded: stay safe
      const p = state.players[name];
      const res = zero();
      const minus = zero();
      const plus = zero();
      RES.forEach((t, i) => {
        const lo = rng.min[i];
        const hi = rng.max[i];
        const base = p ? p.res[t] : 0;
        const c = lo === hi ? hi : Math.min(hi, Math.max(lo, base));
        res[t] = c;
        minus[t] = c - lo;
        plus[t] = hi - c;
      });
      const uncertain = RES.some((t) => minus[t] > 0 || plus[t] > 0);
      return { res, minus, plus, uncertain, source: "worlds" };
    }

    // What the box shows: the cards that are certain (`sure`, the per-type
    // minimum), plus `unknown` cards whose type is not, and for one of those the
    // chance of each type (`could`). Every possible hand is `sure` plus some
    // `unknown` more cards.
    function handView(name) {
      const rng = worlds.range(name);
      const mean = worlds.mean(name);
      const sure = zero();
      const extra = zero();
      if (rng && mean) {
        RES.forEach((t, i) => {
          sure[t] = rng.min[i];
          extra[t] = Math.max(0, mean[i] - rng.min[i]);
        });
      } else {
        // Engine off: the simple model's floor, and its candidate sets for the rest.
        const v = inspectSimple(name);
        const p = state.players[name];
        const share = (sets, r) => (p ? sets.reduce((s, set) => s + (set.includes(r) ? 1 / set.length : 0), 0) : 0);
        RES.forEach((t) => {
          sure[t] = v.res[t] - v.minus[t];
          extra[t] = p ? Math.max(0, v.res[t] - sure[t] + share(p.unknownSets, t) - share(p.lostSets, t)) : 0;
        });
      }
      const nSure = RES.reduce((s, t) => s + sure[t], 0);
      const unknown = Math.max(0, totalBest(name) - nSure);
      const z = RES.reduce((s, t) => s + extra[t], 0);
      const could = Object.fromEntries(RES.map((t) => [t, z > 0 ? extra[t] / z : 0]));
      return { sure, unknown, could, source: rng && mean ? "worlds" : "simple" };
    }

    // What the `unknown` cards of handView(name) can be together, most likely
    // first: [{ cards: { brick: 1, wool: 1 }, p }]. This is the full story;
    // unknownGroups splits it by the steal each card came from where that is
    // exact. null with the engine off.
    function unknownCombos(name) {
      if (comboCache.v !== handVersion) comboCache = { v: handVersion, m: new Map() };
      if (comboCache.m.has(name)) return comboCache.m.get(name);
      const hands = worlds.hands(name);
      const rng = worlds.range(name);
      let out = null;
      if (hands && rng) {
        out = [...hands]
          .map(([key, p]) => {
            const c = key.split(",").map(Number);
            const cards = {};
            RES.forEach((t, i) => {
              if (c[i] > rng.min[i]) cards[t] = c[i] - rng.min[i];
            });
            return { cards, p };
          })
          .sort((a, b) => b.p - a.p);
      }
      comboCache.m.set(name, out);
      return out;
    }

    // The same unknown cards in groups, for the box: a card from one hidden
    // steal whose type is independent of everything else unknown is a group of
    // its own (from = the victim), the rest stay together as one group (from =
    // null, listed first). Each group: { n, from, combos: [{ cards, p }] } with
    // combos as in unknownCombos (one card each for a steal). Together they say
    // exactly what unknownCombos says. [] if nothing is unknown, null with the engine off.
    function unknownGroups(name) {
      if (groupCache.v !== handVersion) groupCache = { v: handVersion, m: new Map() };
      if (groupCache.m.has(name)) return groupCache.m.get(name);
      const g = worlds.groups(name);
      let out = null;
      if (g) {
        out = [];
        const nRest = handView(name).unknown - g.steals.length;
        if (nRest > 0) {
          const combos = [...g.rest]
            .map(([key, p]) => {
              const c = key.split(",").map(Number);
              const cards = {};
              RES.forEach((t, i) => {
                if (c[i] > 0) cards[t] = c[i];
              });
              return { cards, p };
            })
            .sort((a, b) => b.p - a.p);
          out.push({ n: nRest, from: null, combos });
        }
        for (const s of g.steals) {
          const combos = RES.map((t, i) => ({ cards: { [t]: 1 }, p: s.p[i] }))
            .filter((c) => c.p > 0)
            .sort((a, b) => b.p - a.p);
          out.push({ n: 1, from: s.victim, sid: s.sid, combos });
        }
      }
      groupCache.m.set(name, out);
      return out;
    }

    const worldsInfo = () => ({ count: worlds.size(), ...worlds.status });

    // Best available hand size: the worlds' answer when they all agree, else the
    // simple tracker's.
    function totalBest(name) {
      const r = worlds.totalRange(name);
      return r && r.min === r.max ? r.min : total(name);
    }

    // Feed colonist's real hand sizes ({ name: count }) in at a quiet moment.
    const observeHands = (hands) => {
      handVersion++;
      return worlds.observe(hands);
    };

    return {
      state,
      processLine,
      snapshot,
      total,
      inspect,
      inspectSimple,
      handView,
      unknownCombos,
      unknownGroups,
      worldsInfo,
      devEstimate,
      vpSuspects,
      // Our own held dev cards by type, e.g. { Knight: 1, Monopoly: 1 } (null = unknown).
      setMyDev: (obj) => {
        state.myDev = obj ? { ...obj } : null;
        devVersion++;
      },
      totalBest,
      totalRange: (n) => worlds.totalRange(n),
      observeHands,
      stealOdds,
      robAdvice,
      setCurrentPlayer,
      playerBefore,
      setupDone,
      blockedFor,
      ports,
      setMe: (n) => (state.me = n),
    };
  }

  return { createTracker, estimateDev, RES, COSTS, PIECES, ROB_MIN, VP_SHOW, VP_OTHER_MAX, VP_SURE, DEV_TYPES, DEV_TOTAL, DEV_HAZARD };
});
